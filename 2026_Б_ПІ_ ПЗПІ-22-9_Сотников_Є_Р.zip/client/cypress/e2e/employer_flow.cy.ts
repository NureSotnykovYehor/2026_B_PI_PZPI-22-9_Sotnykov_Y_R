describe('TechScreen Platform E2E Tests', () => {
  const randomEmail = `employer_${Date.now()}@test.com`;
  const password = 'e2epassword123';

  beforeEach(() => {
    // Navigate to the app
    cy.visit('/');
  });

  it('Visits the Login Page and fails login with bad credentials', () => {
    // We expect to see "Welcome Back" on the login page
    cy.contains('Welcome Back');
    
    // Attempt login with non-existent credentials
    cy.get('input[type="email"]').type('fake-tester-not-real@example.com');
    cy.get('input[type="password"]').type('wrongpassword');
    cy.contains('button', 'Sign In').click();

    // Should show error from backend (either Invalid credentials or user not found)
    cy.get('.auth-error').should('be.visible');
  });

  it('Registers a new employer, logs in, and navigates to Billing', () => {
    // 1. Switch to Registration Mode
    cy.contains('Sign up').click();
    cy.contains('Create Account').should('be.visible');

    // 2. Fill out registration form
    cy.get('input[type="text"]').type('E2E Employer');
    cy.get('input[type="email"]').type(randomEmail);
    cy.get('input[type="password"]').type(password);
    
    // Submit registration
    cy.contains('button', 'Sign Up').click();

    // 3. Verify Registration Success message and switch back to login
    cy.contains('Registration successful', { timeout: 10000 }).should('be.visible');

    // 4. Log in with the newly created account
    cy.get('input[type="email"]').clear().type(randomEmail);
    cy.get('input[type="password"]').clear().type(password);
    cy.contains('button', 'Sign In').click();

    // 5. Verify successful login by checking dashboard element
    cy.url({ timeout: 10000 }).should('include', '/employer/dashboard');
    cy.contains('Rooms', { matchCase: false }).should('be.visible');

    // 6. Click on Billing / Plans in Sidebar
    cy.contains('Billing / Plans', { matchCase: false }).click();

    // 7. Verify Billing page loaded
    cy.url({ timeout: 10000 }).should('include', '/employer/billing');
    cy.contains('Управління Підпискою').should('be.visible');
    cy.contains('Standard', { matchCase: false }).should('be.visible');
    cy.contains('Premium', { matchCase: false }).should('be.visible');
  });
});
