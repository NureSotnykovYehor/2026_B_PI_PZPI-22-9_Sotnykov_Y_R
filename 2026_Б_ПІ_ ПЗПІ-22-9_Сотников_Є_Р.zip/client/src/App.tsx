import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { AuthPage } from './pages/AuthPage';
import { useAuthStore } from './stores/authStore';

// Protective wrapper for routes
const ProtectedRoute = ({ children, allowedRoles }: { children: React.ReactNode, allowedRoles?: string[] }) => {
  const { isAuthenticated, user } = useAuthStore();
  
  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return children;
};

import { EmployerDashboard } from './pages/EmployerDashboard';
import { EmployerAnalytics } from './pages/EmployerAnalytics';
import { GlobalCandidates } from './pages/GlobalCandidates';
import { EmployerTasks } from './pages/EmployerTasks';
import { CandidateJoin } from './pages/CandidateJoin';
import { CandidateIDE } from './pages/CandidateIDE';
import { EmployerBilling } from './pages/EmployerBilling';
import { BillingSuccess } from './pages/BillingSuccess';
import { EmployerProfile } from './pages/EmployerProfile';

// Temp Stubs for other pages
const CandidateDashboard = () => <div className="app-container"><h1 style={{padding:'20px'}}>Candidate Area (Waiting for link...)</h1></div>;

export const App = () => {
  const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID || '';

  return (
    <GoogleOAuthProvider clientId={clientId}>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<AuthPage />} />
        <Route path="/register" element={<AuthPage />} />
        
        {/* Employer Routes */}
        <Route path="/employer/dashboard" element={
          <ProtectedRoute allowedRoles={['EMPLOYER', 'ADMIN']}>
            <EmployerDashboard />
          </ProtectedRoute>
        } />
        <Route path="/employer/tasks" element={
          <ProtectedRoute allowedRoles={['EMPLOYER', 'ADMIN']}>
            <EmployerTasks />
          </ProtectedRoute>
        } />
        <Route path="/employer/rooms/:roomId" element={
          <ProtectedRoute allowedRoles={['EMPLOYER', 'ADMIN']}>
            <EmployerAnalytics />
          </ProtectedRoute>
        } />
        <Route path="/employer/analytics" element={
          <ProtectedRoute allowedRoles={['EMPLOYER', 'ADMIN']}>
            <GlobalCandidates />
          </ProtectedRoute>
        } />

        <Route path="/employer/billing" element={
          <ProtectedRoute allowedRoles={['EMPLOYER', 'ADMIN']}>
            <EmployerBilling />
          </ProtectedRoute>
        } />
        <Route path="/employer/billing/success" element={
          <ProtectedRoute allowedRoles={['EMPLOYER', 'ADMIN']}>
            <BillingSuccess />
          </ProtectedRoute>
        } />
        <Route path="/employer/profile" element={
          <ProtectedRoute allowedRoles={['EMPLOYER', 'ADMIN']}>
            <EmployerProfile />
          </ProtectedRoute>
        } />

        {/* Candidate Routes */}
        <Route path="/candidate/dashboard" element={
          <ProtectedRoute allowedRoles={['CANDIDATE']}>
            <CandidateDashboard />
          </ProtectedRoute>
        } />
        
        {/* Exam Session Routes */}
        <Route path="/exam/:roomId/join" element={<CandidateJoin />} />
        <Route path="/exam/:roomId/ide" element={
          <ProtectedRoute allowedRoles={['CANDIDATE']}>
            <CandidateIDE />
          </ProtectedRoute>
        } />
      </Routes>
    </BrowserRouter>
    </GoogleOAuthProvider>
  );
};

export default App;
