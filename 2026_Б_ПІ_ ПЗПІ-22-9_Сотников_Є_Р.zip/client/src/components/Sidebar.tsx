import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { LayoutDashboard, FileCode2, Users, LogOut, Code2, CreditCard, UserCircle } from 'lucide-react';
import './Sidebar.css';

export const Sidebar: React.FC = () => {
  const { user, logout } = useAuthStore();

  return (
    <div className="sidebar glass-panel">
      <div className="sidebar-brand">
        <Code2 size={24} className="brand-icon" />
        <h2>TechScreen</h2>
      </div>

      <nav className="sidebar-nav">
        <NavLink to="/employer/dashboard" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <LayoutDashboard size={20} />
          Rooms
        </NavLink>
        <NavLink to="/employer/tasks" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <FileCode2 size={20} />
          Tasks Library
        </NavLink>
        <NavLink to="/employer/analytics" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <Users size={20} />
          Candidates
        </NavLink>
        <NavLink to="/employer/billing" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <CreditCard size={20} />
          Billing / Plans
        </NavLink>
        <NavLink to="/employer/profile" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <UserCircle size={20} />
          Profile
        </NavLink>
      </nav>

      <div className="sidebar-footer">
        <div className="user-info">
          <div className="user-name">{user?.name}</div>
          <div className="user-badge">{user?.subscription || 'FREE'} PLAN</div>
        </div>
        <button className="logout-btn" onClick={logout}>
          <LogOut size={18} />
          Logout
        </button>
      </div>
    </div>
  );
};
