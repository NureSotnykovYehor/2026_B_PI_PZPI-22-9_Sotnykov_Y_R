import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { CheckCircle } from 'lucide-react';

export const BillingSuccess: React.FC = () => {
  const navigate = useNavigate();
  const { fetchUser } = useAuthStore();

  useEffect(() => {
    // The webhook handles the actual upgrade, but we fetch the user 
    // again to update the UI state locally
    const updateLocalState = async () => {
       try {
          // This will re-fetch the /me route and update user in store
          await fetchUser(); 
       } catch (err) {
          console.error("Failed to update user after billing", err);
       }
    };

    updateLocalState();
  }, [fetchUser]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh', background: 'var(--bg-color)', color: 'var(--text-color)' }}>
      <CheckCircle size={80} color="#10b981" style={{ marginBottom: '20px' }} />
      <h1 style={{ marginBottom: '10px' }}>Оплата Успішна!</h1>
      <p style={{ color: 'var(--text-secondary)', marginBottom: '30px' }}>
        Дякуємо за підписку. Ваш план успішно оновлено до PREMIUM. 
        Тепер вам доступні просунуті AI інструменти.
      </p>
      <button 
        onClick={() => navigate('/employer')} 
        style={{ padding: '12px 24px', background: 'var(--primary-color)', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold' }}>
        Повернутися до Дашборду
      </button>
    </div>
  );
};
