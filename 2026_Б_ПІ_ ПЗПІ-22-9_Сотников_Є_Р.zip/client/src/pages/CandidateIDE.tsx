import React, { useEffect, useState, useRef } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { io, Socket } from 'socket.io-client';
import { useAuthStore } from '../stores/authStore';
import { Play, CheckCircle, Clock, Lightbulb, Activity } from 'lucide-react';
import Editor, { useMonaco } from '@monaco-editor/react';
import './CandidateIDE.css';

interface Task {
  _id: string;
  title: string;
  description: string;
  type: string;
  language: string;
  difficulty?: string;
  starterCode: string;
  testCases?: { input: string, expectedOutput: string }[];
}

export const CandidateIDE: React.FC = () => {
  const { roomId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { user, token } = useAuthStore();
  
  const [task] = useState<Task | null>(location.state?.task || null);
  const [room] = useState<any>(location.state?.room || null);
  const [participation] = useState<any>(location.state?.participation || null);
  
  const getInitialCode = () => {
     if (!task?.starterCode) return '// Write your code here';
     if (typeof task.starterCode === 'string') return task.starterCode;
     return Object.values(task.starterCode)[0] as string || '// Write your code here';
  };
  const [code, setCode] = useState(getInitialCode());
  const [consoleOutput, setConsoleOutput] = useState('Workspace ready...');
  const [isRunning, setIsRunning] = useState(false);
  
  // Timer State
  const [timeLeft, setTimeLeft] = useState(0);

  // Database Preview State
  const [dbData, setDbData] = useState<{columns: string[], rows: any[]}>({columns: [], rows: []});
  const [dbState, setDbState] = useState<'LOADING' | 'READY' | 'NONE'>('NONE');
  
  // Cognitive Load Index (CLI) State
  const [cli, setCli] = useState(0);
  const [hintsGiven, setHintsGiven] = useState(0);
  const [showHint, setShowHint] = useState<string | null>(null);
  const failedRuns = useRef(0);

  const socketRef = useRef<Socket | null>(null);
  const metricsCache = useRef<{type: string, timestamp: Date}[]>([]);

  // Setup Timer logic
  useEffect(() => {
     if (!room?.settings?.duration || !participation?.startedAt) return;
     const maxSeconds = room.settings.duration * 60;
     const started = new Date(participation.startedAt).getTime();
     
     const intvl = setInterval(() => {
        const now = new Date().getTime();
        const elapsedSeconds = Math.floor((now - started) / 1000);
        const remaining = maxSeconds - elapsedSeconds;
        setTimeLeft(remaining > 0 ? remaining : 0);
        
        if (remaining <= 0) {
           clearInterval(intvl);
           handleFinish(); // auto submit
        }
     }, 1000);

     // CLI Calculation Loop
     const cliIntvl = setInterval(() => {
        const w = 1.2;
        const w_d = 1.5;
        const w_h = 0.8;
        
        // O: Base objectives + frustration (failed runs)
        const currentO = (task?.testCases?.length || 2) + failedRuns.current;
        
        // D: Difficulty multiplier
        const currentD = task?.difficulty?.toUpperCase() === 'HARD' ? 3 : task?.difficulty?.toUpperCase() === 'MEDIUM' ? 2 : 1;
        
        // Formula: CLI = (O * w + D * w_d) / (1 + H * w_h)
        const calculatedCLI = (currentO * w + currentD * w_d) / (1 + hintsGiven * w_h);
        setCli(Number(calculatedCLI.toFixed(2)));

        // Trigger Hint if Cognitive Load is too high (e.g. > 6)
        if (calculatedCLI > 6 && !showHint) {
           setShowHint("Система помітила високе навантаження. Підказка: Спробуйте розділити задачу на менші підфункції або вивести проміжні результати через console.log.");
           setHintsGiven(h => h + 1);
        }
     }, 3000);

     return () => { clearInterval(intvl); clearInterval(cliIntvl); };
  }, [room, participation, task, hintsGiven, showHint]);

  const formatTime = (seconds: number) => {
     const h = Math.floor(seconds/3600);
     const m = Math.floor((seconds%3600)/60);
     const s = seconds%60;
     return `${h ? h+':' : ''}${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
  };

  // Setup Socket & Anti-cheat listeners
  useEffect(() => {
    // 1. Setup Socket
    socketRef.current = io('http://localhost:4000');
    if (user) {
      socketRef.current.emit('joinRoom', { roomId, userId: user.id, role: 'CANDIDATE' });
    }

    // 2. Anti-cheat Visibility listener
    const handleVisibility = () => {
      if (document.hidden) {
         metricsCache.current.push({ type: 'tab_switch', timestamp: new Date() });
         socketRef.current?.emit('candidateActivity', { status: 'TAB_SWITCHED' });
         alert("Warning: Tab switching is recorded!");
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    const handlePaste = () => {
        metricsCache.current.push({ type: 'paste', timestamp: new Date() });
    };
    document.addEventListener('paste', handlePaste);

    // Periodically send metrics
    const interval = setInterval(() => {
      if (metricsCache.current.length > 0) {
        fetch(`http://localhost:4000/api/candidate/rooms/${roomId}/metrics`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
          body: JSON.stringify({
            events: metricsCache.current,
            tabSwitchesCount: metricsCache.current.filter(e => e.type === 'tab_switch').length
          })
        }).catch(err => console.error("Metrics sync error", err));
        
        metricsCache.current = []; // clear cache
      }
    }, 10000);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      document.removeEventListener('paste', handlePaste);
      clearInterval(interval);
      socketRef.current?.disconnect();
    };
  }, [roomId, user, token]);

  // Fetch db preview
  useEffect(() => {
     const fetchDbPreview = async () => {
        try {
           setDbState('LOADING');
           const res = await fetch(`http://localhost:4000/api/candidate/rooms/${roomId}/db-preview`, {
              headers: { 'Authorization': `Bearer ${token}` }
           });
           const data = await res.json();
           if (data.columns && data.columns.length > 0) {
              setDbData(data);
              setDbState('READY');
           } else {
              setDbState('NONE');
           }
        } catch (err) {
           setDbState('NONE');
        }
     };
     if (roomId) fetchDbPreview();
  }, [roomId, token]);

  const handleRun = async () => {
    setIsRunning(true);
    setConsoleOutput('Running in isolated Docker container...');
    
    try {
      const res = await fetch(`http://localhost:4000/api/candidate/rooms/${roomId}/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ code, language: task?.language || 'javascript' })
      });
      const data = await res.json();
      setConsoleOutput(`Status: ${data.submission.status}\n\nLogs:\n${data.submission.logs}`);
      
      // If code failed, increase cognitive load penalty
      if (data.submission.status === 'ERROR' || data.submission.status === 'FAILED') {
          failedRuns.current += 1;
      }

    } catch (err) {
      setConsoleOutput("Execution Failed: Network Error.");
      failedRuns.current += 1;
    } finally {
      setIsRunning(false);
    }
  };

  const handleFinish = async () => {
    if (!window.confirm("Are you sure you want to submit? You cannot undo this action.")) return;
    try {
      // Get the absolute latest code directly from the Monaco instance to avoid React state staleness in tests
      // @ts-ignore
      const finalCodeToSubmit = window.monacoEditor ? window.monacoEditor.getValue() : code;

      await fetch(`http://localhost:4000/api/candidate/rooms/${roomId}/finish`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({ code: finalCodeToSubmit })
      });
      alert("Exam submitted successfully! The AI will now evaluate your work.");
      navigate('/');
    } catch (err) {
      alert("Failed to submit.");
    }
  };

  return (
    <div className="ide-layout">
      {/* LEFT PANEL: Task Description */}
      <div className="ide-panel task-panel glass-panel">
        <div className="panel-header">
           <h3>Task Instructions</h3>
           <div className="timer"><Clock size={16}/> {formatTime(timeLeft)}</div>
        </div>
        <div className="task-content" style={{overflowY: 'auto'}}>
          <h2>{task?.title || 'Loading Task...'}</h2>
          <p>{task?.description || 'Please wait while instructions are fetched from the server.'}</p>

          <div className="cli-monitor" style={{marginTop:'15px', background:'rgba(16, 185, 129, 0.1)', border:'1px solid rgba(16, 185, 129, 0.3)', padding:'10px', borderRadius:'8px', display:'flex', alignItems:'center', gap:'10px'}}>
             <Activity size={18} color="#10b981" />
             <div style={{flex: 1}}>
                <div style={{fontSize:'12px', color:'var(--text-secondary)'}}>Cognitive Load Index (CLI)</div>
                <div style={{fontSize:'16px', fontWeight:'bold', color: cli > 6 ? '#ef4444' : '#10b981'}}>{cli}</div>
             </div>
             <div style={{fontSize:'11px', color:'var(--text-secondary)', textAlign:'right'}}>
                Hints Active: {hintsGiven} <br/>
                Failed Runs: {failedRuns.current}
             </div>
          </div>

          {showHint && (
             <div className="hint-box" style={{marginTop:'15px', background:'rgba(245, 158, 11, 0.1)', border:'1px solid #f59e0b', padding:'15px', borderRadius:'8px', color:'#fcd34d'}}>
                <div style={{display:'flex', alignItems:'center', gap:'8px', marginBottom:'8px'}}>
                   <Lightbulb size={18} /> <b>AI System Hint</b>
                </div>
                <div style={{fontSize:'13px', lineHeight:'1.5'}}>{showHint}</div>
                <button 
                  onClick={() => setShowHint(null)} 
                  style={{marginTop:'10px', background:'none', border:'1px solid #f59e0b', color:'#fcd34d', padding:'4px 10px', borderRadius:'4px', cursor:'pointer', fontSize:'12px'}}
                >
                  Зрозуміло, приховати
                </button>
             </div>
          )}

          {task?.testCases && task.testCases.length > 0 && (
             <div className="test-cases-preview" style={{marginTop:'20px'}}>
                <h4 style={{marginBottom:'10px', color:'var(--primary-color)'}}>Test Cases to Pass</h4>
                {task.testCases.map((tc, idx) => (
                   <div key={idx} style={{background:'var(--glass-bg)', padding:'10px', borderRadius:'8px', marginBottom:'8px', border:'1px solid var(--border-color)'}}>
                      <div style={{fontSize:'13px', marginBottom:'4px'}}><b>Test {idx+1}:</b></div>
                      <div style={{fontFamily:'monospace', fontSize:'12px', background:'rgba(0,0,0,0.2)', padding:'4px', borderRadius:'4px', marginBottom:'4px'}}>Input: {tc.input}</div>
                      <div style={{fontFamily:'monospace', fontSize:'12px', background:'rgba(0,0,0,0.2)', padding:'4px', borderRadius:'4px'}}>Expected: {tc.expectedOutput}</div>
                   </div>
                ))}
             </div>
          )}

          {dbState === 'LOADING' && <p style={{marginTop:'20px', color:'var(--text-secondary)'}}>Loading Database Preview...</p>}
          {dbState === 'READY' && (
             <div className="db-preview" style={{marginTop:'20px'}}>
               <h4 style={{marginBottom:'10px', color:'var(--primary-color)'}}>Live Database Preview</h4>
               <div style={{overflowX: 'auto', background:'var(--glass-bg)', padding:'10px', borderRadius:'8px', border:'1px solid var(--border-color)'}}>
                 <table style={{width:'100%', textAlign:'left', borderCollapse:'collapse'}}>
                    <thead>
                      <tr>
                        {dbData.columns.map(col => <th key={col} style={{padding:'8px', borderBottom:'1px solid var(--border-color)'}}>{col}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {dbData.rows.map((row, idx) => (
                        <tr key={idx}>
                           {dbData.columns.map(col => <td key={col} style={{padding:'8px', fontSize:'13px'}}>{String(row[col])}</td>)}
                        </tr>
                      ))}
                    </tbody>
                 </table>
               </div>
             </div>
          )}
        </div>
      </div>

      {/* MID PANEL: Editor Replacement */}
      <div className="ide-panel editor-panel glass-panel">
        <div className="panel-header">
           <h3>Code Editor ({task?.language})</h3>
           <div className="editor-controls">
             <button className="glass-button run-btn" onClick={handleRun} disabled={isRunning}>
               <Play size={16}/> {isRunning ? 'Executing...' : 'Run Code'}
             </button>
             <button className="glass-button finish-btn" onClick={handleFinish}>
               <CheckCircle size={16}/> Submit
             </button>
           </div>
        </div>
        <div className="editor-wrapper" style={{padding:0, height: '400px'}}>
           <Editor
             height="100%"
             language={task?.language === 'python' ? 'python' : 'javascript'}
             theme="vs-dark"
             value={code}
             options={{
               minimap: { enabled: false },
               fontSize: 14,
               inlayHints: { enabled: 'on' }
             }}
             onChange={(val) => {
               setCode(val || '');
               socketRef.current?.emit('candidateActivity', { status: 'TYPING' });
             }}
             onMount={(editor, monaco) => {
               // Expose editor for Cypress E2E tests
               // @ts-ignore
               window.monacoEditor = editor;

               // Configure JS/TS inlay hints
               monaco.languages.typescript.javascriptDefaults.setInlayHintsOptions({
                 includeInlayParameterNameHints: "all",
                 includeInlayParameterNameHintsWhenArgumentMatchesName: true,
                 includeInlayFunctionParameterTypeHints: true,
                 includeInlayVariableTypeHints: true,
                 includeInlayPropertyDeclarationTypeHints: true,
                 includeInlayFunctionLikeReturnTypeHints: true,
                 includeInlayEnumMemberValueHints: true,
               });

               // Custom Python Inlay Hints provider
               monaco.languages.registerInlayHintsProvider('python', {
                 provideInlayHints: (model, range, token) => {
                   const text = model.getValue();
                   const hints = [];
                   
                   // Basic regex to find function calls and guess parameters
                   // E.g., looking for def func(a, b):
                   const defRegex = /def\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(([^)]*)\)/g;
                   const functions = {};
                   let match;
                   while ((match = defRegex.exec(text)) !== null) {
                       const funcName = match[1];
                       const params = match[2].split(',').map(p => p.trim().split(':')[0].split('=')[0].trim()).filter(p => p && p !== 'self');
                       functions[funcName] = params;
                   }

                   // Find function calls
                   const callRegex = /([a-zA-Z_][a-zA-Z0-9_]*)\s*\(([^)]*)\)/g;
                   while ((match = callRegex.exec(text)) !== null) {
                       const funcName = match[1];
                       const argsStr = match[2];
                       if (functions[funcName] && argsStr.trim() !== '') {
                           const startPos = match.index + funcName.length + 1; // after '('
                           const args = argsStr.split(',');
                           let currentPos = startPos;
                           
                           args.forEach((arg, i) => {
                               if (functions[funcName][i] && !arg.includes('=')) {
                                   const pos = model.getPositionAt(currentPos);
                                   hints.push({
                                       position: pos,
                                       label: `${functions[funcName][i]}:`,
                                       kind: monaco.languages.InlayHintKind.Parameter,
                                       paddingRight: true
                                   });
                               }
                               currentPos += arg.length + 1; // +1 for comma
                           });
                       }
                   }

                   return { hints, dispose: () => {} };
                 }
               });
             }}
           />
        </div>
      </div>

      {/* RIGHT PANEL: Console Output */}
      <div className="ide-panel console-panel glass-panel">
        <div className="panel-header">
           <h3>Console Output</h3>
        </div>
        <pre className="console-output">
          {consoleOutput}
        </pre>
      </div>
    </div>
  );
};
