import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { AlertCircle, TerminalSquare } from 'lucide-react';
import '../pages/AuthPage.css'; // Reuse container styles

export const CandidateJoin: React.FC = () => {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const { token, login, logout } = useAuthStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Always force a clean slate when visiting a new exam link
  useEffect(() => {
     logout();
  }, [logout]);

  const handleAuthAndJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    let currentToken = token;

    if (email && password) {
       try {
         const authRes = await fetch('http://localhost:4000/api/auth/login', {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ email, password })
         });
         const authData = await authRes.json();
         if (!authRes.ok) throw new Error(authData.message || 'Login failed');
         
         login(authData.user, authData.token);
         currentToken = authData.token;
       } catch (err: any) {
         setError(err.message);
         setLoading(false);
         return;
       }
    }
    
    try {
      const res = await fetch(`http://localhost:4000/api/candidate/rooms/${roomId}/join`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${currentToken}`
        }
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to join room');

      // Joined successfully, moving to IDE
      navigate(`/exam/${roomId}/ide`, { state: { task: data.task, room: data.room, participation: data.participation } });

    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box glass-panel" style={{maxWidth: '600px'}}>
        <div className="auth-header">
          <TerminalSquare size={48} className="brand-icon" />
          <h2>Interview Session</h2>
          <p>Please read the instructions carefully before starting.</p>
        </div>

        {error && <div className="auth-error">{error}</div>}

        <div className="rules-section" style={{background: 'rgba(0,0,0,0.2)', padding: '20px', borderRadius: '8px', marginBottom: '20px', lineHeight: '1.6'}}>
          <h4 style={{display: 'flex', alignItems: 'center', gap: '8px', color: '#ffcc00', marginBottom: '10px'}}>
            <AlertCircle size={18}/> Rules & Anti-Cheat
          </h4>
          <ul style={{color: 'var(--text-secondary)', fontSize: '14px', paddingLeft: '20px'}}>
            <li>Do not switch browser tabs or open other applications.</li>
            <li>Copying and pasting large chunks of code is monitored.</li>
            <li>Your typing speed and behavior are recorded for AI analysis.</li>
            <li>Ensure you have a stable internet connection.</li>
            <li>If the timer runs out, your session will be auto-submitted.</li>
          </ul>
        </div>

        <form onSubmit={handleAuthAndJoin}>
            <div style={{marginBottom: '20px', background: 'rgba(255,255,255,0.05)', padding: '20px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.1)'}}>
               <h4 style={{marginBottom: '10px'}}>Candidate Authentication</h4>
               <p style={{fontSize:'13px', color:'var(--text-secondary)', marginBottom:'15px'}}>Please enter the Explicit Credentials provided by your Employer to access this test.</p>
               <input type="email" className="glass-input" placeholder="Candidate Email" value={email} onChange={e=>setEmail(e.target.value)} required style={{marginBottom: '10px', width: '100%', boxSizing:'border-box'}} />
               <input type="password" className="glass-input" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required style={{width: '100%', boxSizing:'border-box'}} />
            </div>

          <button 
            type="submit"
            className="glass-button full-width" 
            disabled={loading}
            style={{padding: '16px', fontSize: '18px', display:'flex', justifyContent:'center'}}
          >
            {loading ? 'Entering...' : 'Log In & Start Exam'}
          </button>
        </form>
      </div>
    </div>
  );
};
