import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { Sidebar } from '../components/Sidebar';
import { ArrowLeft, UserCheck, AlertTriangle, Lock } from 'lucide-react';
import './EmployerAnalytics.css';

interface Evaluation {
  _id: string;
  candidateId: { _id: string, name: string, email: string };
  candidateMetrics: { totalRuns: number, copyPasteCount: number, timeSpent: number };
  aiEvaluation: { score: number, summary: string, bugsAnalysis: string, originalityAnalysis: string, finalCode: string, customAiAnomalyScore?: number };
}

export const EmployerAnalytics: React.FC = () => {
  const { roomId } = useParams();
  const { token } = useAuthStore();
  const [evaluations, setEvaluations] = useState<Evaluation[]>([]);
  const [room, setRoom] = useState<any>(null);
  const [dbPreview, setDbPreview] = useState<{columns: string[], rows: any[]}|null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    
    const fetchAnalytics = async () => {
      try {
        const res = await fetch(`http://localhost:4000/api/rooms/${roomId}/analytics`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();
        setEvaluations(data.analytics || []);
        setRoom(data.room);

        if (data.room?.taskId?.dbIntegration?.type && data.room?.taskId?.dbIntegration?.type !== 'NONE') {
            try {
                const dbRes = await fetch(`http://localhost:4000/api/candidate/rooms/${roomId}/db-preview`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (dbRes.ok) {
                    const dbData = await dbRes.json();
                    setDbPreview(dbData);
                }
            } catch (err) {
                console.error("Failed to load db preview");
            }
        }
        
        // Polling logic: if any evaluation is still pending, schedule another fetch
        const hasPending = (data.analytics || []).some((e: any) => e.aiEvaluation?.summary?.includes('Pending'));
        if (hasPending) {
            timeoutId = setTimeout(fetchAnalytics, 3000);
        }
      } catch (err) {
        console.error(err);
      } finally { setLoading(false); }
    };
    
    fetchAnalytics();

    return () => clearTimeout(timeoutId);
  }, [roomId, token]);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div className="layout">
      <Sidebar />
      <main className="main-content">
        <header className="content-header">
          <div>
            <Link to="/employer/dashboard" className="back-link"><ArrowLeft size={16}/> Back to Rooms</Link>
            <h1 style={{marginTop:'12px'}}>Room Analytics</h1>
            <p>Review candidate performance and AI scores.</p>
          </div>
        </header>

        {loading ? (
          <div className="loader">Loading results...</div>
        ) : (
          <div>
            {room && (
              <div className="glass-panel" style={{padding: '25px', marginBottom: '30px'}}>
                 <h2>Room Details</h2>
                 <div style={{display:'flex', gap:'30px', marginTop:'15px', color:'var(--text-secondary)'}}>
                    <div style={{flex: 2}}>
                       <p style={{color:'white', fontWeight:'bold', fontSize:'16px'}}>{room?.taskId?.title}</p>
                       <p style={{fontSize:'13px', marginTop:'5px', lineHeight: '1.5'}}>{room?.taskId?.description}</p>
                    </div>
                    <div style={{flex: 1, borderLeft: '1px solid rgba(255,255,255,0.1)', paddingLeft: '20px'}}>
                       <p style={{marginBottom: '5px'}}><b>Duration:</b> {room?.settings?.duration} mins</p>
                       <p style={{marginBottom: '5px'}}><b>Max Limits:</b> {room?.maxCandidates}</p>
                       <p><b>Status:</b> {room?.status}</p>
                    </div>
                 </div>

                 {room?.allowedCandidates?.length > 0 && (
                    <div style={{marginTop: '25px', paddingTop: '20px', borderTop: '1px solid rgba(255,255,255,0.1)'}}>
                       <h4 style={{marginBottom:'12px', color:'var(--primary-color)'}}>Invited Candidates</h4>
                       <div style={{display:'flex', flexWrap:'wrap', gap:'10px'}}>
                          {room.allowedCandidates.map((c: any) => (
                             <div key={c._id} style={{background:'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', padding:'8px 12px', borderRadius:'6px', fontSize:'13px'}}>
                                <b>{c.name}</b> ({c.email})
                             </div>
                          ))}
                       </div>
                    </div>
                 )}

                 {dbPreview && dbPreview.columns?.length > 0 && (
                    <div style={{marginTop: '25px', paddingTop: '20px', borderTop: '1px solid rgba(255,255,255,0.1)'}}>
                       <h4 style={{marginBottom:'10px', color:'#00d4ff'}}>Database Attached: {room?.taskId?.dbIntegration?.tableName} ({room?.taskId?.dbIntegration?.type})</h4>
                       <div style={{maxHeight:'250px', overflow:'auto', borderRadius:'8px', border:'1px solid rgba(255,255,255,0.1)', background:'rgba(0,0,0,0.5)'}}>
                           <table style={{width:'100%', borderCollapse:'collapse', fontSize:'13px', textAlign:'left'}}>
                              <thead>
                                 <tr style={{background:'rgba(255,255,255,0.05)'}}>
                                     {dbPreview.columns.map(col => <th key={col} style={{padding:'10px', borderBottom:'1px solid rgba(255,255,255,0.1)'}}>{col}</th>)}
                                 </tr>
                              </thead>
                              <tbody>
                                 {dbPreview.rows.map((row, idx) => (
                                    <tr key={idx}>
                                        {dbPreview.columns.map(col => <td key={col} style={{padding:'8px 10px', borderBottom:'1px solid rgba(255,255,255,0.05)'}}>{String(row[col])}</td>)}
                                    </tr>
                                 ))}
                              </tbody>
                           </table>
                       </div>
                    </div>
                 )}
              </div>
            )}

            <h3 style={{marginBottom: '15px'}}>Candidate Evaluations</h3>
            <div className="analytics-list">
            {evaluations.length === 0 ? (
              <div className="glass-panel" style={{padding:'40px', textAlign:'center', color:'var(--text-secondary)'}}>
                No candidates have completed this interview yet.
              </div>
            ) : (
              evaluations.map(ev => (
                <div key={ev._id} className="eval-card glass-panel" style={{cursor: 'pointer', transition: 'all 0.3s ease'}} onClick={() => setExpandedId(expandedId === ev._id ? null : ev._id)}>
                   <div className="eval-header">
                     <div>
                       <h3>{ev.candidateId?.name || 'Unknown Candidate'}</h3>
                       <span style={{fontSize:'13px', color:'var(--text-secondary)'}}>{ev.candidateId?.email}</span>
                     </div>
                     <div className={`score-badge ${ev.aiEvaluation?.score >= 7 ? 'high' : 'low'}`}>
                        {ev.aiEvaluation?.score || 0}/10
                     </div>
                   </div>
                   
                   <div className="eval-body">
                     <p><b>AI Summary:</b> {ev.aiEvaluation?.summary || 'Pending evaluation...'}</p>
                     {ev.aiEvaluation?.customAiAnomalyScore !== undefined && (
                         <div style={{marginTop: '15px', padding: '15px', background: 'rgba(245, 158, 11, 0.1)', border: '1px solid #f59e0b', borderRadius: '8px'}}>
                             <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px'}}>
                                 <span style={{color: '#f59e0b', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px'}}>
                                     <Lock size={16} /> Premium AI: Cheat Probability
                                 </span>
                                 <span style={{color: '#f59e0b', fontWeight: 'bold'}}>{ev.aiEvaluation.customAiAnomalyScore}%</span>
                             </div>
                             <div style={{width: '100%', height: '8px', background: 'rgba(0,0,0,0.3)', borderRadius: '4px', overflow: 'hidden', marginBottom: '8px'}}>
                                 <div style={{
                                     width: `${ev.aiEvaluation.customAiAnomalyScore}%`, 
                                     height: '100%', 
                                     background: ev.aiEvaluation.customAiAnomalyScore > 50 ? '#ef4444' : '#10b981',
                                     transition: 'width 1s ease-in-out'
                                 }}></div>
                             </div>
                             <div style={{fontSize: '12px', color: 'var(--text-secondary)'}}>
                                 *This metric uses our custom local Neural Network (brain.js) to analyze typing speed, tab switches, and execution patterns to detect potentially suspicious behavior.
                             </div>
                         </div>
                     )}
                   </div>
                   
                   <div className="eval-metrics" style={{ marginTop: '15px' }}>
                     <div className="metric">
                       <UserCheck size={16}/> {ev.candidateMetrics.totalRuns} Code Executions
                     </div>
                     <div className="metric">
                       <AlertTriangle size={16}/> {ev.candidateMetrics.copyPasteCount} Paste Events
                     </div>
                     <div className="metric">
                       <div style={{fontSize: '13px', border:'1px solid var(--border-color)', padding:'4px 8px', borderRadius:'12px'}}>
                         ⏱️ {formatTime(ev.candidateMetrics.timeSpent || 0)} Time Spent
                       </div>
                     </div>
                   </div>

                   {expandedId === ev._id && (
                     <div className="eval-expanded-details" style={{marginTop: '20px', paddingTop: '20px', borderTop: '1px solid var(--border-color)'}}>
                        <p style={{marginBottom: '10px'}}><b>Bugs Analysis:</b> {ev.aiEvaluation?.bugsAnalysis || 'N/A'}</p>
                        <p style={{marginBottom: '15px', color:'var(--primary-color)'}}><b>Originality Analysis:</b> {ev.aiEvaluation?.originalityAnalysis || 'N/A'}</p>
                        
                        <div style={{background: 'rgba(0,0,0,0.3)', padding: '15px', borderRadius: '8px', overflowX: 'auto'}}>
                          <div style={{fontSize: '12px', color: 'var(--text-secondary)', marginBottom: '8px'}}>Final Submitted Code:</div>
                          <pre style={{fontFamily: 'monospace', fontSize: '13px', lineHeight: '1.4', margin: 0, whiteSpace: 'pre-wrap'}}>
                            {ev.aiEvaluation?.finalCode || '// No code submitted.'}
                          </pre>
                        </div>
                     </div>
                   )}
                </div>
              ))
            )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
