import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { Check, Zap, Lock, Shield } from 'lucide-react';
import './EmployerDashboard.css';
import './EmployerBilling.css';

export const EmployerBilling: React.FC = () => {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const formRef = useRef<HTMLFormElement>(null);
  const [liqpayData, setLiqpayData] = useState('');
  const [liqpaySignature, setLiqpaySignature] = useState('');

  const currentPlan = user?.subscription || 'STANDARD';

  const handleUpgrade = async () => {
    try {
      setLoading(true);
      setError('');
      
      const res = await fetch('http://localhost:4000/api/billing/liqpay-params', {
        headers: {
          'Authorization': `Bearer ${useAuthStore.getState().token}`
        }
      });
      
      if (!res.ok) {
        throw new Error('Не вдалося згенерувати платіжні дані. Спробуйте пізніше.');
      }
      
      const { data, signature } = await res.json();
      
      setLiqpayData(data);
      setLiqpaySignature(signature);
      
      // Auto-submit the form after state updates
      setTimeout(() => {
         if (formRef.current) {
            formRef.current.submit();
         }
      }, 100);

    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="billing-container dashboard-content">
      <div className="billing-header">
        <h1>Управління Підпискою</h1>
        <p>
          Оберіть план, який найкраще підходить для потреб вашої компанії у технічному рекрутингу.
        </p>
      </div>

      {error && (
         <div style={{ background: 'rgba(239,68,68,0.1)', color: '#ef4444', padding: '15px', borderRadius: '8px', marginBottom: '30px', textAlign: 'center' }}>
            {error}
         </div>
      )}

      <div className="billing-cards">
        
        {/* STANDARD TIER */}
        <div className="billing-card standard">
          {currentPlan === 'STANDARD' && (
             <div className="current-badge">ПОТОЧНИЙ ПЛАН</div>
          )}
          <h2 className="card-title">Standard</h2>
          <div className="card-price">Безкоштовно</div>
          
          <ul className="features-list">
             <li><Check size={18} color="#10b981"/> Базове середовище (IDE)</li>
             <li><Check size={18} color="#10b981"/> Аналітика кімнат</li>
             <li><Check size={18} color="#10b981"/> Базовий ШІ Звіт (Claude Sonnet 4.6)</li>
          </ul>

          <button 
            className="billing-btn outline"
            onClick={() => navigate('/employer/dashboard')}
          >
            {currentPlan === 'STANDARD' ? 'Перейти до панелі керування' : 'Продовжити на Standard'}
          </button>
        </div>

        {/* PREMIUM TIER */}
        <div className="billing-card premium">
          {currentPlan === 'PREMIUM' && (
             <div className="current-badge">ПОТОЧНИЙ ПЛАН</div>
          )}
          <h2 className="card-title">
             Premium <Zap size={24} color="#f59e0b" fill="#f59e0b" />
          </h2>
          <div className="card-price">500 ₴ <span>/ місяць</span></div>
          
          <ul className="features-list">
             <li><Check size={18} color="var(--primary-color)"/> Усе зі Standard</li>
             <li><Check size={18} color="var(--primary-color)"/> Просунутий ШІ Звіт (Claude Opus 4.8)</li>
             <li><Lock size={18} color="#f59e0b"/> Власна ML Нейромережа (brain.js)</li>
             <li><Shield size={18} color="#ef4444"/> Аналіз ймовірності обману (Anti-Cheat)</li>
          </ul>

          {currentPlan !== 'PREMIUM' ? (
             <div style={{display:'flex', gap:'10px', flexDirection:'column'}}>
               <button 
                 onClick={handleUpgrade}
                 disabled={loading}
                 className="billing-btn primary"
               >
                 {loading ? 'Формування платежу...' : 'Оформити Premium'}
               </button>
               {process.env.NODE_ENV !== 'production' && (
                 <button 
                   onClick={async () => {
                      setLoading(true);
                      try {
                         await fetch('http://localhost:4000/api/billing/mock-success', {
                           method: 'POST',
                           headers: { 'Authorization': `Bearer ${useAuthStore.getState().token}` }
                         });
                         navigate('/employer/billing/success');
                      } catch (err) {
                         setError("Mock upgrade failed");
                         setLoading(false);
                      }
                   }}
                   disabled={loading}
                   className="billing-btn outline"
                   style={{ borderColor: '#10b981', color: '#10b981' }}
                 >
                   Dev: Mock Upgrade (Local)
                 </button>
               )}
             </div>
          ) : (
             <button 
               disabled 
               className="billing-btn outline"
             >
               Активно
             </button>
          )}

          {/* Hidden form for LiqPay Checkout */}
          <form ref={formRef} method="POST" action="https://www.liqpay.ua/api/3/checkout" acceptCharset="utf-8" style={{display: 'none'}}>
            <input type="hidden" name="data" value={liqpayData} />
            <input type="hidden" name="signature" value={liqpaySignature} />
          </form>

        </div>

      </div>
    </div>
  );
};
