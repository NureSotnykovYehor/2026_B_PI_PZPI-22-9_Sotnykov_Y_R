import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Sidebar } from '../components/Sidebar';
import { Plus, Users, Clock, PlayCircle, X, Trash2 } from 'lucide-react';
import { useAuthStore } from '../stores/authStore';
import './EmployerDashboard.css';

interface Room {
  _id: string;
  maxCandidates: number;
  status: string;
  settings: { duration: number };
  taskId: { title: string, _id: string };
}
interface Task {
  _id: string; title: string; difficulty: string;
}

export const EmployerDashboard: React.FC = () => {
  const { token } = useAuthStore();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState('');
  const [selectedDuration, setSelectedDuration] = useState('60');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  // Explicit candidates
  const [candidates, setCandidates] = useState<{name: string, email: string, password: string}[]>([]);

  const fetchRooms = async () => {
    try {
      const res = await fetch('http://localhost:4000/api/rooms', { headers: { 'Authorization': `Bearer ${token}` } });
      const data = await res.json();
      setRooms(data);
    } catch (err) { console.error("Failed to load rooms", err); } 
      finally { setLoading(false); }
  };

  const fetchTasks = async () => {
    try {
      const res = await fetch('http://localhost:4000/api/tasks', { headers: { 'Authorization': `Bearer ${token}` } });
      setTasks(await res.json());
    } catch (err) { console.error(err); }
  };

  useEffect(() => {
    fetchRooms();
    fetchTasks();
  }, [token]);

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask) return;

    try {
      await fetch('http://localhost:4000/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ taskId: selectedTask, duration: parseInt(selectedDuration), candidates })
      });
      setIsModalOpen(false);
      setCandidates([]);
      fetchRooms(); // refresh list
    } catch (err) { console.error(err); }
  };

  const copyInvite = (roomId: string) => {
    const link = `${window.location.origin}/exam/${roomId}/join`;
    navigator.clipboard.writeText(link);
    setCopiedId(roomId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDeleteRoom = async (roomId: string) => {
    if (!window.confirm('Are you sure you want to delete this room and all its analytics?')) return;
    try {
      await fetch(`http://localhost:4000/api/rooms/${roomId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      fetchRooms();
    } catch(err) {
      console.error(err);
    }
  };

  return (
    <div className="layout">
      <Sidebar />
      <main className="main-content">
        <header className="content-header">
          <div>
            <h1>Interview Rooms</h1>
            <p>Manage your active sessions and evaluate candidates.</p>
          </div>
          <button className="glass-button create-room-btn" onClick={() => setIsModalOpen(true)}>
            <Plus size={18} />
            Create Room
          </button>
        </header>

        {loading ? (
          <div className="loader">Loading rooms...</div>
        ) : (
          <div className="rooms-grid">
            {rooms.length === 0 ? (
              <div className="empty-state glass-panel">
                <PlayCircle size={48} className="empty-icon" />
                <h3>No Rooms Found</h3>
                <p>You haven't created any interview rooms yet.</p>
              </div>
            ) : (
              rooms.map(room => (
                <div key={room._id} className="room-card glass-panel">
                  <div className="room-header">
                    <h3>{room.taskId?.title || 'Unknown Task'}</h3>
                    <span className={`status-badge ${room.status.toLowerCase()}`}>
                      {room.status}
                    </span>
                  </div>
                  <div className="room-stats">
                    <div className="stat">
                      <Clock size={16} />
                      {room.settings?.duration || 0} mins
                    </div>
                    <div className="stat">
                      <Users size={16} />
                      Limit: {room.maxCandidates}
                    </div>
                  </div>
                  <div className="room-actions">
                    <Link to={`/employer/rooms/${room._id}`} className="glass-button secondary" style={{justifyContent:'center', display:'flex', textDecoration:'none', alignItems:'center', flex: 1}}>
                       View Details
                    </Link>
                    <button className="glass-button secondary" onClick={() => copyInvite(room._id)} style={{flex: 1}}>
                       {copiedId === room._id ? 'Copied! ✅' : 'Copy Invite'}
                    </button>
                    <button className="glass-button secondary" onClick={() => handleDeleteRoom(room._id)} style={{padding: '10px', color: '#ff4d4d'}}>
                       <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {isModalOpen && (
          <div className="modal-overlay" style={{zIndex: 1000}}>
            <div className="modal-content glass-panel" style={{maxWidth: '500px', padding: '30px', position: 'relative', maxHeight: '90vh', overflowY: 'auto'}}>
              <button className="close-btn" style={{position:'absolute', right: '15px', top: '15px', background:'none', border:'none', color:'white', cursor:'pointer'}} onClick={() => setIsModalOpen(false)}>
                 <X size={20} />
              </button>
              <h2>Create Interview Room</h2>
              <p style={{color:'var(--text-secondary)', marginBottom:'20px'}}>Select a task and configure limits.</p>
              
              <form onSubmit={handleCreateRoom} style={{display:'flex', flexDirection:'column', gap:'15px'}}>
                <div className="form-group">
                  <label>Select Task</label>
                  <select className="glass-input" value={selectedTask} onChange={e => setSelectedTask(e.target.value)} required>
                    <option value="" disabled>-- Select a Task --</option>
                    {tasks.map(t => <option key={t._id} value={t._id}>{t.title} ({t.difficulty})</option>)}
                  </select>
                </div>

                <div className="form-group">
                  <label>Duration (Minutes)</label>
                  <input type="number" className="glass-input" value={selectedDuration} onChange={e => setSelectedDuration(e.target.value)} required min={5} />
                </div>

                <div className="form-group">
                  <label>Invited Candidates</label>
                  {candidates.map((c, idx) => (
                      <div key={idx} style={{display:'flex', gap:'8px', marginBottom:'10px', background:'rgba(255,255,255,0.05)', padding:'10px', borderRadius:'8px'}}>
                         <div style={{flex: 1, display:'flex', flexDirection:'column', gap:'5px'}}>
                           <input className="glass-input" placeholder="Full Name" value={c.name} onChange={e => { const nc = [...candidates]; nc[idx].name=e.target.value; setCandidates(nc); }} required />
                           <input type="email" className="glass-input" placeholder="Email" value={c.email} onChange={e => { const nc = [...candidates]; nc[idx].email=e.target.value; setCandidates(nc); }} required />
                           <input className="glass-input" placeholder="Password" value={c.password} onChange={e => { const nc = [...candidates]; nc[idx].password=e.target.value; setCandidates(nc); }} required />
                         </div>
                         <button type="button" className="glass-button error" style={{alignSelf:'center', padding:'8px'}} onClick={() => { const nc = [...candidates]; nc.splice(idx,1); setCandidates(nc); }}>
                           <X size={16}/>
                         </button>
                      </div>
                  ))}
                  <button type="button" className="glass-button secondary" onClick={() => setCandidates([...candidates, {name:'', email:'', password: Math.random().toString(36).slice(-8)}])}>
                    + Add Candidate
                  </button>
                </div>

                <button type="submit" className="glass-button create-room-btn" style={{marginTop:'10px', justifyContent:'center'}}>
                   Launch Room
                </button>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
