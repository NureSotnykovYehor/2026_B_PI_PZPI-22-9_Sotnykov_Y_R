import React, { useEffect, useState } from 'react';
import { Sidebar } from '../components/Sidebar';
import { useAuthStore } from '../stores/authStore';
import { Trash2, Edit2, Plus } from 'lucide-react';
import './EmployerDashboard.css'; // Reusing dashboard layouts

interface Task {
  _id: string;
  title: string;
  description: string;
  language: string;
  difficulty: string;
  starterCode: any;
  testCases: any[];
  dbIntegration?: any;
}

export const EmployerTasks: React.FC = () => {
  const { token } = useAuthStore();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  // Form state
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [language, setLanguage] = useState('javascript');
  const [starterCode, setStarterCode] = useState('');
  
  // Custom Tests & DB Integration State
  const [testCases, setTestCases] = useState<{input: string, expectedOutput: string}[]>([]);
  const [dbType, setDbType] = useState('NONE');
  const [dbConnectionString, setDbConnectionString] = useState('');
  const [dbTableName, setDbTableName] = useState('');

  const fetchTasks = async () => {
    try {
      const res = await fetch('http://localhost:4000/api/tasks', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setTasks(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [token]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = editingId ? `http://localhost:4000/api/tasks/${editingId}` : 'http://localhost:4000/api/tasks';
      const method = editingId ? 'PUT' : 'POST';
      await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          title,
          description,
          difficulty: 'MEDIUM',
          starterCode: { [language]: starterCode },
          testCases,
          dbIntegration: {
             type: dbType,
             connectionString: dbConnectionString,
             tableName: dbTableName
          }
        })
      });
      setShowForm(false);
      setEditingId(null);
      // Reset form
      setTitle(''); setDescription(''); setStarterCode('');
      setTestCases([]); setDbType('NONE'); setDbConnectionString(''); setDbTableName('');
      fetchTasks();
    } catch (err) {
      console.error(err);
    }
  };

  const handleEditClick = (t: Task) => {
      setEditingId(t._id);
      setTitle(t.title);
      setDescription(t.description || '');
      setLanguage(Object.keys(t.starterCode || {})[0] || 'javascript');
      setStarterCode(t.starterCode ? Object.values(t.starterCode)[0] as string : '');
      setTestCases(t.testCases || []);
      setDbType(t.dbIntegration?.type || 'NONE');
      setDbConnectionString(t.dbIntegration?.connectionString || '');
      setDbTableName(t.dbIntegration?.tableName || '');
      setShowForm(true);
      window.scrollTo(0, 0);
  };

  const handleDeleteTask = async (taskId: string) => {
      if (!window.confirm("Are you sure you want to delete this task?")) return;
      try {
          await fetch(`http://localhost:4000/api/tasks/${taskId}`, {
              method: 'DELETE',
              headers: { 'Authorization': `Bearer ${token}` }
          });
          fetchTasks();
      } catch (err) {
          console.error(err);
      }
  };

  return (
    <div className="layout">
      <Sidebar />
      <main className="main-content">
        <header className="content-header">
          <div>
            <h1>Task Library</h1>
            <p>Manage your pool of interview questions.</p>
          </div>
          <button className="glass-button create-room-btn" onClick={() => {
            if (showForm) {
               setShowForm(false); setEditingId(null);
               setTitle(''); setDescription(''); setStarterCode('');
               setTestCases([]); setDbType('NONE'); setDbConnectionString(''); setDbTableName('');
            } else {
               setShowForm(true);
            }
          }}>
            <Plus size={18} />
            {showForm ? 'Cancel Form' : 'New Task'}
          </button>
        </header>

        {showForm && (
          <div className="glass-panel" style={{padding: '24px', marginBottom: '30px'}}>
            <h2>{editingId ? 'Edit Task' : 'Create New Task'}</h2>
            <form onSubmit={handleCreate} style={{display: 'flex', flexDirection: 'column', gap: '16px', marginTop: '15px'}}>
              <div style={{display:'flex', gap:'16px'}}>
                 <input className="glass-input" style={{flex:2}} placeholder="Task Title (e.g. Invert Binary Tree)" value={title} onChange={e=>setTitle(e.target.value)} required />
                 <select className="glass-input" style={{flex:1}} value={language} onChange={e=>setLanguage(e.target.value)}>
                    <option value="javascript">JavaScript</option>
                    <option value="python">Python</option>
                 </select>
              </div>
              <textarea className="glass-input" placeholder="Task Description" rows={4} value={description} onChange={e=>setDescription(e.target.value)} required />
              <textarea className="glass-input" placeholder="Starter Code" rows={6} value={starterCode} onChange={e=>setStarterCode(e.target.value)} style={{fontFamily: 'monospace'}} />
              
              {/* Test Cases Builder */}
              <h4>Test Cases</h4>
              {testCases.map((tc, idx) => (
                  <div key={idx} style={{display:'flex', gap:'8px', marginBottom: '8px'}}>
                     <input className="glass-input" placeholder="Execution Input (e.g. myFunction(1))" value={tc.input} onChange={e => {
                         const newTc = [...testCases]; newTc[idx].input = e.target.value; setTestCases(newTc);
                     }} required />
                     <input className="glass-input" placeholder="Expected Output (JSON string)" value={tc.expectedOutput} onChange={e => {
                         const newTc = [...testCases]; newTc[idx].expectedOutput = e.target.value; setTestCases(newTc);
                     }} required />
                     <button type="button" className="glass-button error" style={{padding:'8px', background:'rgba(255,0,0,0.1)'}} onClick={() => {
                         const newTc = [...testCases]; newTc.splice(idx, 1); setTestCases(newTc);
                     }}>X</button>
                  </div>
              ))}
              <button type="button" className="glass-button" onClick={() => setTestCases([...testCases, {input:'', expectedOutput:''}])} style={{alignSelf:'flex-start', fontSize:'12px'}}>+ Add Test Case</button>

              {/* Database Integration */}
              <h4 style={{marginTop: '10px'}}>Database Integration</h4>
              <select className="glass-input" value={dbType} onChange={e=>setDbType(e.target.value)}>
                 <option value="NONE">None</option>
                 <option value="POSTGRES">PostgreSQL</option>
                 <option value="MONGO">MongoDB</option>
              </select>
              {dbType !== 'NONE' && (
                  <div style={{display:'flex', gap:'8px', marginTop:'8px'}}>
                      <input className="glass-input" placeholder="Connection String (URI)" value={dbConnectionString} onChange={e=>setDbConnectionString(e.target.value)} style={{flex:2}} required />
                      <input className="glass-input" placeholder="Table or Collection Name" value={dbTableName} onChange={e=>setDbTableName(e.target.value)} style={{flex:1}} required />
                  </div>
              )}

              <button type="submit" className="glass-button" style={{alignSelf: 'flex-start', marginTop: '20px', background: 'var(--primary-color)'}}>Save Task</button>
            </form>
          </div>
        )}

        {loading ? (
          <div className="loader">Loading tasks...</div>
        ) : (
          <div className="rooms-grid">
            {tasks.map(task => (
              <div key={task._id} className="room-card glass-panel">
                <div className="room-header">
                  <h3>{task.title}</h3>
                  <span className="status-badge open">{task.difficulty}</span>
                </div>
                <div className="room-stats">
                   <span>Language: <b>{task.language}</b></span>
                </div>
                <div className="room-actions" style={{display: 'flex', gap: '10px', marginTop: '15px'}}>
                   <button className="glass-button secondary" style={{flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '5px'}} onClick={() => handleEditClick(task)}>
                      <Edit2 size={16}/> Edit
                   </button>
                   <button className="glass-button secondary" onClick={() => handleDeleteTask(task._id)} style={{padding: '10px', color: '#ff4d4d'}}>
                       <Trash2 size={16} />
                   </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};
