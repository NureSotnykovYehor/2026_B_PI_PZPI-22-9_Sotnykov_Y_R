import React, { useEffect, useState } from 'react';
import { Sidebar } from '../components/Sidebar';
import { useAuthStore } from '../stores/authStore';
import { UserCheck, AlertTriangle, FileCode2 } from 'lucide-react';

interface GlobalAnalytics {
  _id: string;
  candidateId: { _id: string, name: string, email: string };
  roomId: { _id: string, taskId: { title: string } };
  candidateMetrics: { totalRuns: number, copyPasteCount: number };
  aiEvaluation: { score: number, summary: string, bugsAnalysis: string };
}

export const GlobalCandidates: React.FC = () => {
  const { token } = useAuthStore();
  const [evaluations, setEvaluations] = useState<GlobalAnalytics[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchGlobalAnalytics = async () => {
      try {
        const res = await fetch(`http://localhost:4000/api/rooms/analytics/global`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();
        setEvaluations(data || []);
      } catch (err) {
        console.error(err);
      } finally { setLoading(false); }
    };
    fetchGlobalAnalytics();
  }, [token]);

  return (
    <div className="layout">
      <Sidebar />
      <main className="main-content">
        <header className="content-header">
          <div>
            <h1>All Candidates</h1>
            <p>Unified view of your candidates across all interview rooms.</p>
          </div>
        </header>

        {loading ? (
          <div className="loader">Loading analytics...</div>
        ) : (
          <div className="analytics-list">
            {evaluations.length === 0 ? (
              <div className="glass-panel" style={{padding:'40px', textAlign:'center', color:'var(--text-secondary)'}}>
                No candidates have taken an interview yet.
              </div>
            ) : (
              evaluations.map(ev => (
                <div key={ev._id} className="eval-card glass-panel">
                   <div className="eval-header">
                     <div>
                       <h3>{ev.candidateId?.name || 'Unknown Candidate'}</h3>
                       <span style={{fontSize:'13px', color:'var(--text-secondary)'}}>{ev.candidateId?.email}</span>
                     </div>
                     <div style={{display:'flex', gap:'12px', alignItems:'center'}}>
                        <span style={{fontSize:'14px', background:'var(--glass-bg)', padding:'4px 10px', borderRadius:'6px'}}>
                           Task: {ev.roomId?.taskId?.title || 'Deleted Task'}
                        </span>
                        <div className={`score-badge ${ev.aiEvaluation?.score >= 7 ? 'high' : 'low'}`}>
                            {ev.aiEvaluation?.score || 0}/10
                        </div>
                     </div>
                   </div>
                   
                   <div className="eval-body">
                     <p><b>AI Summary:</b> {ev.aiEvaluation?.summary || 'Pending evaluation...'}</p>
                   </div>
                   
                   <div className="eval-metrics">
                     <div className="metric">
                       <UserCheck size={16}/> {ev.candidateMetrics.totalRuns} Runs
                     </div>
                     <div className="metric">
                       <AlertTriangle size={16}/> {ev.candidateMetrics.copyPasteCount} Pastes
                     </div>
                   </div>
                </div>
              ))
            )}
          </div>
        )}
      </main>
    </div>
  );
};
