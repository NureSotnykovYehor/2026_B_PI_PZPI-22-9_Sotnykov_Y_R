import { test, expect } from '@playwright/test';

test.describe('Authentication UI Flow', () => {
  test('Employer can login and see dashboard', async ({ page }) => {
    // Mock the backend API
    await page.route('**/api/auth/login', route => route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ token: 'mock-token', user: { id: '1', role: 'EMPLOYER' } })
    }));

    await page.route('**/api/rooms', route => route.fulfill({
      status: 200, contentType: 'application/json', body: '[]'
    }));

    // 1. Visit Login
    await page.goto('/login');
    
    // 2. Check UI elements
    await expect(page.locator('h2')).toContainText('Welcome Back');
    
    // 3. Login
    await page.fill('input[type="email"]', 'employer@test.com');
    await page.fill('input[type="password"]', 'password123');
    await page.click('button[type="submit"]');

    // 4. Wait for redirect or capture error
    try {
      await page.waitForURL('**/employer/dashboard', { timeout: 8000 });
      await expect(page.locator('h1')).toContainText('Interview Rooms');
    } catch (e) {
      if (await page.locator('.auth-error').isVisible()) {
        const errText = await page.textContent('.auth-error');
        console.error('UI Login Error:', errText);
      }
      throw e;
    }
  });
});
