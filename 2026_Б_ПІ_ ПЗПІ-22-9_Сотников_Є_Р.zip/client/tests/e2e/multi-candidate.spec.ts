import { test, expect } from '@playwright/test';

test.describe.serial('Full Lifecycle E2E - Multi-User Analytics', () => {
  const roomId = 'mock-room-123';

  test('Employer fetches Room details and verifies Empty Analytics', async ({ page }) => {
     // Mock Login
     await page.route('**/api/auth/login', route => route.fulfill({
       status: 200, contentType: 'application/json', body: JSON.stringify({ token: 'mock-token', user: { role: 'EMPLOYER' } })
     }));
     // Mock Rooms
     await page.route('**/api/rooms', route => route.fulfill({
       status: 200, contentType: 'application/json', 
       body: JSON.stringify([{ _id: roomId, name: 'Mock Session', status: 'OPEN', durationLimit: 60 }])
     }));
     // Mock Analytics empty
     await page.route(`**/api/rooms/${roomId}/analytics`, route => route.fulfill({
       status: 200, contentType: 'application/json', body: JSON.stringify({ analytics: [] })
     }));

     await page.goto('/login');
     await page.fill('input[type="email"]', 'employer@test.com');
     await page.fill('input[type="password"]', 'password123');
     await page.click('button[type="submit"]');
     
     await expect(page.locator('h1')).toContainText('Interview Rooms');
     
     // Verify "No candidates" in analytics initially
     await page.goto(`/employer/rooms/${roomId}`);
     await expect(page.locator('text=No candidates have completed this interview yet.')).toBeVisible();
  });

  test('Candidate 1 and Candidate 2 evaluations appear in Analytics Dashboard', async ({ page }) => {
     // Mock Login
     await page.route('**/api/auth/login', route => route.fulfill({
       status: 200, contentType: 'application/json', body: JSON.stringify({ token: 'mock-token', user: { role: 'EMPLOYER' } })
     }));
     // Mock Analytics populated with 2 candidates (representing Backend Evaluation Output)
     await page.route(`**/api/rooms/${roomId}/analytics`, route => route.fulfill({
       status: 200, contentType: 'application/json', 
       body: JSON.stringify({
         analytics: [
           {
             _id: 'eval1',
             candidateId: { _id: 'can1', name: 'Ada Lovelace', email: 'ada@test.com' },
             candidateMetrics: { totalRuns: 1, copyPasteCount: 0 },
             aiEvaluation: { score: 10, summary: 'Excellent logic.', bugsAnalysis: 'No bugs.' }
           },
           {
             _id: 'eval2',
             candidateId: { _id: 'can2', name: 'Bad Coder', email: 'bad@test.com' },
             candidateMetrics: { totalRuns: 4, copyPasteCount: 2 },
             aiEvaluation: { score: 2, summary: 'Logic missing.', bugsAnalysis: 'Contains errors.' }
           }
         ]
       })
     }));

     // Ensure token exists in Zustand so ProtectedRoute allows us 
     await page.goto('/login');
     await page.fill('input[type="email"]', 'employer@test.com');
     await page.fill('input[type="password"]', 'password123');
     await page.click('button[type="submit"]');

     // Navigate directly to target Room
     await page.goto(`/employer/rooms/${roomId}`);
     
     // Evaluate Candidate 1
     await expect(page.locator('text=Ada Lovelace')).toBeVisible();
     await expect(page.locator('text=10/10')).toBeVisible();
     await expect(page.locator('text=Excellent logic.')).toBeVisible();

     // Evaluate Candidate 2
     await expect(page.locator('text=Bad Coder')).toBeVisible();
     await expect(page.locator('text=2/10')).toBeVisible();
     await expect(page.locator('text=Logic missing.')).toBeVisible();
  });
});
