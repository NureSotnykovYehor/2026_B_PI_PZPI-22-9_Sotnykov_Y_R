import { test, expect } from '@playwright/test';

test.describe('Tasks Flow', () => {
  test('Employer can navigate to tasks library and open creation form', async ({ page }) => {
    // Mock APIs
    await page.route('**/api/auth/login', route => route.fulfill({
      status: 200, contentType: 'application/json', body: JSON.stringify({ token: 'mock-token', user: { role: 'EMPLOYER' } })
    }));
    await page.route('**/api/rooms', route => route.fulfill({ status: 200, contentType: 'application/json', body: '[]' }));
    await page.route('**/api/tasks', route => route.fulfill({ status: 200, contentType: 'application/json', body: '[]' }));

    // 1. Login
    await page.goto('/login');
    await page.fill('input[type="email"]', 'employer@test.com');
    await page.fill('input[type="password"]', 'password123');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/employer/dashboard');

    // 2. Click sidebar navigation text
    await page.click('text=Tasks Library');
    await page.waitForURL('**/employer/tasks');

    // 3. Confirm target UI
    await expect(page.locator('h1')).toContainText('Task Library');

    // 4. Reveal Form
    await page.click('button:has-text("New Task")');

    // 5. Verify inputs are interactable
    await expect(page.locator('input[placeholder*="Task Title"]')).toBeVisible();
    await expect(page.locator('textarea[placeholder="Task Description"]')).toBeVisible();
  });
});
