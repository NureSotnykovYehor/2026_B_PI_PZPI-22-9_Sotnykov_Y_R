const mongoose = require('mongoose');

async function addRoom3() {
    try {
        require('dotenv').config();
        
        await mongoose.connect(process.env.MONGO_URI);
        
        const Employer = mongoose.model('User', new mongoose.Schema({}, { strict: false }));
        const employer = await Employer.findOne({ role: 'EMPLOYER' });
        if (!employer) throw new Error("No employer found");

        const Task = mongoose.model('Task', new mongoose.Schema({}, { strict: false }));
        
        const starterCode = `const { MongoClient } = require("mongodb");

// 1. Create an async function called 'countActiveUsers'
// 2. Connect to Mongo using process.env.DB_CONNECTION_STRING
// 3. Query the collection 'interview_users' for active users
// 4. Return the integer count of how many active users there are.
async function countActiveUsers() {
  const uri = process.env.DB_CONNECTION_STRING;
  const client = new MongoClient(uri);
  await client.connect();
  const db = client.db();
  
  // Your logic here
  
}
`;

        const task3 = await Task.create({
            title: 'Database: Count Active Users with Tests',
            description: 'Write an asynchronous function `countActiveUsers()` that uses `process.env.DB_CONNECTION_STRING` to connect to Mongo, queries the `interview_users` collection for users with `status: "active"`, and returns the integer count of such users.',
            difficulty: 'HARD',
            starterCode: { 'javascript': starterCode },
            testCases: [
                {
                    input: 'countActiveUsers()',
                    expectedOutput: 2,
                    isHidden: false
                }
            ],
            dbIntegration: { 
               type: 'MONGO', 
               connectionString: process.env.MONGO_URI, 
               tableName: 'interview_users' 
            }
        });

        const Room = mongoose.model('Room', new mongoose.Schema({}, { strict: false }));
        
        const room3 = await Room.create({
            employerId: employer._id,
            taskId: task3._id,
            status: 'OPEN',
            maxCandidates: 5,
            settings: { duration: 60, allowedLanguages: ['javascript'] }
        });

        console.log("Room 3 Created Successfully with Async Test Cases!");
        console.log("Room 3 ID:", room3._id.toString());

        await mongoose.disconnect();
    } catch(e) {
        console.error(e);
    }
}

addRoom3();
