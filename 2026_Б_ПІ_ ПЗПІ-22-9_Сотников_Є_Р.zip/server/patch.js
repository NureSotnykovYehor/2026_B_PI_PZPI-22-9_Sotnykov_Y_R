const mongoose = require('mongoose');

async function patch() {
    try {
        require('dotenv').config();
        const uri = process.env.MONGO_URI;
        await mongoose.connect(uri);
        console.log('Connected to Atlas');
        
        const db = mongoose.connection.db;
        const result = await db.collection('tasks').updateMany(
            { "dbIntegration.type": "MONGO" },
            { $set: { "dbIntegration.connectionString": uri } }
        );
        console.log('Tasks patched:', result.modifiedCount);
        
        await mongoose.disconnect();
    } catch(e) {
        console.error(e);
    }
}
patch();
