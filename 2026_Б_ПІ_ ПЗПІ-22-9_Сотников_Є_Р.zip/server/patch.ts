import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Task, { ITask } from './src/models/Task';

dotenv.config();

const patchTasks = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/techscreen');
        console.log('Connected to DB...');

        const tasks = await Task.find({});
        for (let task of tasks) {
            if (task.title === 'Invert Binary Tree') {
                task.testCases = [
                    { 
                        input: 'invertTree({val: 2, left: {val: 1}, right: {val: 3}})', 
                        expectedOutput: '{"val":2,"left":{"val":3},"right":{"val":1}}', 
                        isHidden: false 
                    },
                    { 
                        input: 'invertTree({val: 4, left: {val: 2, left: {val: 1}, right: {val: 3}}, right: {val: 7, left: {val: 6}, right: {val: 9}}})', 
                        expectedOutput: '{"val":4,"left":{"val":7,"left":{"val":9},"right":{"val":6}},"right":{"val":2,"left":{"val":3},"right":{"val":1}}}', 
                        isHidden: false 
                    }
                ];
                await task.save();
                console.log('Patched Invert Binary Tree');
            }
        }
        
        console.log('Patch completed successfully!');
        process.exit(0);
    } catch (err) {
        console.error('Patch error:', err);
        process.exit(1);
    }
};

patchTasks();
