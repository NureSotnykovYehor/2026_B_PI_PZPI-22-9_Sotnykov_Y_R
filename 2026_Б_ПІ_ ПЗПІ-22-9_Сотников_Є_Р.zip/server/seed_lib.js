const mongoose = require('mongoose');

async function seedLibrary() {
    try {
        require('dotenv').config();
        await mongoose.connect(process.env.MONGO_URI);
        
        const Employer = mongoose.model('User', new mongoose.Schema({}, { strict: false }));
        const employer = await Employer.findOne({ role: 'EMPLOYER' });
        if (!employer) {
            console.log("NO EMPLOYER FOUND");
            process.exit(1);
        }

        const Task = mongoose.model('Task', new mongoose.Schema({
            title: String,
            description: String,
            difficulty: String,
            language: String,
            starterCode: mongoose.Schema.Types.Mixed,
            testCases: Array,
            dbIntegration: mongoose.Schema.Types.Mixed
        }, { strict: false }));

        const Room = mongoose.model('Room', new mongoose.Schema({
            employerId: mongoose.Types.ObjectId,
            taskId: mongoose.Types.ObjectId,
            status: String,
            maxCandidates: Number,
            settings: mongoose.Schema.Types.Mixed
        }, { strict: false }));

        await Task.deleteMany({});
        console.log("Cleared Task Library.");
        await Room.deleteMany({});
        console.log("Cleared Rooms.");

        // Create tasks
        const t1 = await Task.create({
            title: 'Algorithm: Two Sum',
            description: 'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target. You may assume that each input would have exactly one solution.',
            difficulty: 'EASY',
            language: 'javascript',
            starterCode: { 'javascript': 'function twoSum(nums, target) {\n  // your code here\n}' },
            testCases: [
                { input: 'twoSum([2,7,11,15], 9)', expectedOutput: [0, 1] },
                { input: 'twoSum([3,2,4], 6)', expectedOutput: [1, 2] }
            ],
            dbIntegration: { type: 'NONE' }
        });

        const t2 = await Task.create({
            title: 'Algorithm: Reverse a String',
            description: 'Write a function that reverses a string. The input string is given as an array of characters s. You must do this by modifying the input array in-place with O(1) extra memory.',
            difficulty: 'EASY',
            language: 'javascript',
            starterCode: { 'javascript': 'function reverseString(s) {\n  // your code here\n}' },
            testCases: [
                { input: 'reverseString(["h","e","l","l","o"])', expectedOutput: ["o","l","l","e","h"] }
            ],
            dbIntegration: { type: 'NONE' }
        });

        const t3 = await Task.create({
            title: 'Database: Fetch Active Users',
            description: 'Write an async function countActiveUsers() that uses process.env.DB_CONNECTION_STRING to connect to Mongo, queries the `interview_users` collection for users with `status: "active"`, and returns the integer count.',
            difficulty: 'HARD',
            language: 'javascript',
            starterCode: { 'javascript': 'const { MongoClient } = require("mongodb");\n\nasync function countActiveUsers() {\n  const client = new MongoClient(process.env.DB_CONNECTION_STRING);\n  await client.connect();\n  const db = client.db();\n  // your code here\n}' },
            testCases: [
                { input: 'countActiveUsers()', expectedOutput: 2 }
            ],
            dbIntegration: { type: 'MONGO', connectionString: process.env.MONGO_URI, tableName: 'interview_users' }
        });

        // Create rooms
        await Room.create([
            { employerId: employer._id, taskId: t1._id, status: 'OPEN', maxCandidates: 5, settings: { duration: 30 } },
            { employerId: employer._id, taskId: t2._id, status: 'OPEN', maxCandidates: 5, settings: { duration: 15 } },
            { employerId: employer._id, taskId: t3._id, status: 'OPEN', maxCandidates: 10, settings: { duration: 60 } }
        ]);
        console.log("Tasks and Rooms created!");
        
        await mongoose.disconnect();
    } catch(e) { console.error(e); }
}
seedLibrary();
