const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
require('dotenv').config();

async function seedRooms() {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        
        const User = mongoose.model('User');
        const Task = mongoose.model('Task');
        const Room = mongoose.model('Room');
        const employer = await User.findOne({ role: 'EMPLOYER' });

        await Room.deleteMany({});
        
        // 1. Create standard candidates
        const salt = await bcrypt.genSalt(10);
        const pass = await bcrypt.hash('pass123', salt);
        
        await User.deleteMany({ role: 'CANDIDATE' });

        const cand1 = await User.create({ name: 'Ivan Frontend', email: 'ivan@test.com', passwordHash: pass, role: 'CANDIDATE' });
        const cand2 = await User.create({ name: 'Maria Database', email: 'maria@test.com', passwordHash: pass, role: 'CANDIDATE' });
        
        const tasks = await Task.find();

        if(tasks.length >= 3) {
            await Room.create([
                { 
                    employerId: employer._id, taskId: tasks[0]._id, status: 'OPEN', 
                    maxCandidates: 5, settings: { duration: 30 }, 
                    allowedCandidates: [cand1._id, cand2._id] 
                },
                { 
                    employerId: employer._id, taskId: tasks[1]._id, status: 'OPEN', 
                    maxCandidates: 5, settings: { duration: 15 }, 
                    allowedCandidates: [cand1._id] 
                },
                { 
                    employerId: employer._id, taskId: tasks[2]._id, status: 'OPEN', 
                    maxCandidates: 10, settings: { duration: 60 }, 
                    allowedCandidates: [cand2._id] 
                }
            ]);
        }
        
        console.log('\n=============================================');
        console.log('         MOCK EXAM ACCOUNTS GENERATED          ');
        console.log('=============================================');
        console.log('CANDIDATE 1 (JS Algorithms) : ivan@test.com / pass123');
        console.log('CANDIDATE 2 (Database & Algorithms) : maria@test.com / pass123');
        console.log('=============================================\n');
        
        await mongoose.disconnect();
    } catch(e) { console.error(e); }
}
seedRooms();
