import { Response } from 'express';
import crypto from 'crypto';
import User from '../models/User';
import Room from '../models/Room';
import RoomCandidate from '../models/RoomCandidate';
import { AuthRequest } from '../middleware/auth';
import { triggerAiEvaluation } from '../services/aiService';

const PUBLIC_KEY = process.env.LIQPAY_PUBLIC_KEY || '';
const PRIVATE_KEY = process.env.LIQPAY_PRIVATE_KEY || '';

/**
 * Generate signature and data for LiqPay Checkout
 */
export const generatePaymentParams = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      res.status(401).json({ message: 'Unauthorized' });
      return;
    }

    const order_id = `ORDER_${userId}_${Date.now()}`;
    const amount = 500; // 500 UAH
    const currency = 'UAH';
    const description = 'Підписка PREMIUM на 1 місяць';

    const jsonString = JSON.stringify({
      public_key: PUBLIC_KEY,
      version: 3,
      action: 'pay',
      amount: amount,
      currency: currency,
      description: description,
      order_id: order_id,
      server_url: 'http://localhost:4000/api/billing/liqpay-callback',
      result_url: 'http://localhost:5173/employer/billing/success',
    });

    // data = base64_encode(json_string)
    const data = Buffer.from(jsonString).toString('base64');

    // signature = base64_encode( sha1( private_key + data + private_key ) )
    const signString = PRIVATE_KEY + data + PRIVATE_KEY;
    const signature = crypto.createHash('sha1').update(signString).digest('base64');

    res.json({ data, signature });
  } catch (error: any) {
    console.error('Error generating payment params:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

/**
 * Handle Server-to-Server webhook from LiqPay
 */
export const liqpayCallback = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { data, signature } = req.body;

    if (!data || !signature) {
      res.status(400).json({ message: 'Missing data or signature' });
      return;
    }

    // Verify signature
    const signString = PRIVATE_KEY + data + PRIVATE_KEY;
    const expectedSignature = crypto.createHash('sha1').update(signString).digest('base64');

    if (signature !== expectedSignature) {
      console.warn('Invalid LiqPay signature attempt.');
      res.status(400).json({ message: 'Invalid signature' });
      return;
    }

    // Decode data
    const decodedData = Buffer.from(data, 'base64').toString('utf-8');
    const parsedData = JSON.parse(decodedData);

    // Check payment status
    if (parsedData.status === 'success' || parsedData.status === 'sandbox') {
       // parsedData.order_id format: ORDER_userId_timestamp
       const orderIdParts = parsedData.order_id.split('_');
       const userId = orderIdParts[1];

       if (userId) {
          // Upgrade user to PREMIUM
          await User.findByIdAndUpdate(userId, { subscription: 'PREMIUM' });
          console.log(`User ${userId} successfully upgraded to PREMIUM via LiqPay.`);

          // BACKGROUND JOB: Re-evaluate all past evaluations with the new PREMIUM AI
          (async () => {
             try {
                console.log(`Starting background re-evaluation for new Premium user ${userId}...`);
                const rooms = await Room.find({ employerId: userId });
                for (const room of rooms) {
                   const participations = await RoomCandidate.find({ roomId: room._id, status: 'FINISHED' });
                   for (const part of participations) {
                       await triggerAiEvaluation(room._id.toString(), part.candidateId.toString());
                   }
                }
                console.log(`Finished background re-evaluation for User ${userId}`);
             } catch (err) {
                console.error(`Failed to background re-evaluate for User ${userId}:`, err);
             }
          })();
       }
    }

    // Always respond with 200 OK to LiqPay to acknowledge receipt
    res.status(200).send('OK');
  } catch (error: any) {
    console.error('Webhook error:', error);
    res.status(500).send('Webhook error');
  }
};

/**
 * Mock endpoint for local testing without LiqPay webhooks
 */
export const mockPaymentSuccess = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      res.status(401).json({ message: 'Unauthorized' });
      return;
    }

    await User.findByIdAndUpdate(userId, { subscription: 'PREMIUM' });
    console.log(`User ${userId} successfully upgraded to PREMIUM via MOCK.`);

    // BACKGROUND JOB: Re-evaluate all past evaluations with the new PREMIUM AI
    (async () => {
       try {
          console.log(`Starting background re-evaluation for new Premium user ${userId}...`);
          const rooms = await Room.find({ employerId: userId });
          for (const room of rooms) {
             const participations = await RoomCandidate.find({ roomId: room._id, status: 'FINISHED' });
             for (const part of participations) {
                 await triggerAiEvaluation(room._id.toString(), part.candidateId.toString());
             }
          }
          console.log(`Finished background re-evaluation for User ${userId}`);
       } catch (err) {
          console.error(`Failed to background re-evaluate for User ${userId}:`, err);
       }
    })();

    res.json({ message: 'Mock upgrade successful' });
  } catch (error: any) {
    console.error('Mock upgrade error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
