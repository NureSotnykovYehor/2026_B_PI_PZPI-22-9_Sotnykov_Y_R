import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import Room from '../models/Room';
import RoomCandidate from '../models/RoomCandidate';
import CodeSubmission from '../models/CodeSubmission';
import TypingMetrics from '../models/TypingMetrics';
import Task from '../models/Task';
import Evaluation from '../models/Evaluation';
import { Client } from 'pg';
import mongoose from 'mongoose';
import { MongoClient } from 'mongodb';
import { triggerAiEvaluation } from '../services/aiService';

export const joinRoom = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id: roomId } = req.params;
    const candidateId = req.user?.id;

    const room = await Room.findById(roomId);
    if (!room || room.status !== 'OPEN') {
      res.status(404).json({ message: 'Room not found or closed' });
      return;
    }
    
    // Explicit candidate check
    if (room.allowedCandidates && room.allowedCandidates.length > 0) {
        if (!room.allowedCandidates.map(id => id.toString()).includes(candidateId)) {
            res.status(403).json({ message: 'You are not on the invited list for this room.' });
            return;
        }
    }

    // Process participant limits and existence
    let participation = await RoomCandidate.findOne({ roomId, candidateId });
    if (!participation) {
      // Check limits
      const currentCandidatesCount = await RoomCandidate.countDocuments({ roomId });
      if (currentCandidatesCount >= room.maxCandidates) {
        res.status(403).json({ message: 'Room reached its max participants limit' });
        return;
      }

      participation = new RoomCandidate({
        roomId,
        candidateId,
        status: 'IN_PROGRESS',
        startedAt: new Date()
      });
      await participation.save();
    } else if (participation.status === 'INVITED') {
      participation.status = 'IN_PROGRESS';
      participation.startedAt = new Date();
      await participation.save();
    }

    const task = await Task.findById(room.taskId);
    if (!task) {
      res.status(404).json({ message: 'Assigned task not found' });
      return;
    }

    // Clean up hidden tests before returning the task to the candidate
    const candidateTask = task.toObject();
    candidateTask.testCases = candidateTask.testCases.filter(test => !test.isHidden);

    res.json({ room, participation, task: candidateTask });
  } catch (error: any) {
    res.status(500).json({ message: 'Error joining room', error: error.message });
  }
};

export const submitMetrics = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id: roomId } = req.params;
    const candidateId = req.user?.id;
    const { events, tabSwitchesCount } = req.body;

    let metrics = await TypingMetrics.findOne({ roomId, candidateId });
    if (!metrics) {
      metrics = new TypingMetrics({ roomId, candidateId, events, tabSwitchesCount });
    } else {
      metrics.events.push(...events);
      metrics.tabSwitchesCount += tabSwitchesCount || 0;
    }

    await metrics.save();
    res.status(200).json({ message: 'Metrics saved' });
  } catch (error: any) {
    res.status(500).json({ message: 'Error saving metrics', error: error.message });
  }
};

import { executeCodeInDocker } from '../services/dockerService';
import { triggerAiEvaluation } from '../services/aiService';

export const runCode = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id: roomId } = req.params;
    const candidateId = req.user?.id;
    const { code, language } = req.body;

    const room = await Room.findById(roomId);
    if (!room) throw new Error("Room not found");
    const task = await Task.findById(room.taskId);
    
    let finalCode = code;
    
    // Auto-append Test Runner logic like Leetcode
    if (task && task.testCases && task.testCases.length > 0) {
        if (language === 'javascript') {
            finalCode += `\n\n// --- AUTO-GENERATED TEST RUNNER ---\n`;
            finalCode += `(async () => {\n`;
            finalCode += `console.log("--------- TEST RESULTS ---------");\n`;
            finalCode += `try {\n`;
            task.testCases.forEach((tc, i) => {
                const safeExpected = JSON.stringify(tc.expectedOutput);
                finalCode += `  const rawRes${i} = eval(\`${tc.input}\`);\n`;
                finalCode += `  const resolvedRes${i} = rawRes${i} instanceof Promise ? await rawRes${i} : rawRes${i};\n`;
                finalCode += `  const res${i} = JSON.stringify(resolvedRes${i});\n`;
                finalCode += `  console.log("Test ${i+1}:", res${i} === ${safeExpected} ? "✅ PASS" : "❌ FAIL (Expected: " + ${safeExpected} + ", Got: " + res${i} + ")");\n`;
            });
            finalCode += `} catch(e) { console.log("Test execution error:", e.message); }\n`;
            finalCode += `})();\n`;
        }
    }

    let executionResult;
    try {
      const connStr = task?.dbIntegration?.connectionString || '';
      executionResult = await executeCodeInDocker(finalCode, language, connStr);
    } catch (dockerErr: any) {
      executionResult = {
        status: 'RUNTIME_ERROR',
        logs: 'Docker execution failed or Docker Desktop is not running locally. Error: ' + dockerErr.message
      };
    }

    const submission = new CodeSubmission({
      roomId,
      candidateId,
      code,
      language,
      status: executionResult.status,
      logs: executionResult.logs
    });

    await submission.save();

    await Evaluation.updateOne(
      { roomId, candidateId },
      { $inc: { 'candidateMetrics.totalRuns': 1 } },
      { upsert: true }
    );

    res.json({ submission });
  } catch (error: any) {
    res.status(500).json({ message: 'Execution error', error: error.message });
  }
};

export const finishSession = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id: roomId } = req.params;
    const candidateId = req.user?.id as string;
    const finalCodeFromSubmit = req.body?.code;

    await RoomCandidate.updateOne(
        { roomId, candidateId },
        { status: 'FINISHED', endedAt: new Date() }
    );

    // Create a pending evaluation so it immediately shows up in analytics
    await Evaluation.updateOne(
        { roomId, candidateId },
        { 
            $setOnInsert: {
                candidateMetrics: { totalRuns: 0, copyPasteCount: 0, timeSpent: 0 },
                aiEvaluation: {
                    score: 0,
                    summary: "Pending evaluation...",
                    originalityAnalysis: "Pending...",
                    bugsAnalysis: "Pending...",
                    finalCode: finalCodeFromSubmit || "Loading..."
                }
            }
        },
        { upsert: true }
    );

    // Call AI in background without blocking response
    triggerAiEvaluation(roomId as string, candidateId as string, finalCodeFromSubmit).catch(err => {
       console.error("AI Evaluation failed in background", err);
    });

    res.json({ message: 'Session completed successfully. AI Evaluation started.' });
  } catch (error: any) {
    console.error('SUPER FATAL ERROR IN FINISH:', error);
    res.status(500).json({ message: 'Error finishing session', error: error.message, stack: error.stack });
  }
};

export const getDbPreview = async (req: AuthRequest, res: Response): Promise<void> => {
   try {
     const { id: roomId } = req.params;
     const room = await Room.findById(roomId);
     if (!room) { res.status(404).json({ message: 'Room not found' }); return; }
     
     const task = await Task.findById(room.taskId);
     if (!task || !task.dbIntegration || task.dbIntegration.type === 'NONE') {
        res.json({ message: 'No DB integration for this task', columns: [], rows: [] }); 
        return;
     }

     const { type, connectionString, tableName } = task.dbIntegration;
     
     // Backend runs on host: so we must replace host.docker.internal mapped for docker with 127.0.0.1 locally
     const localConn = connectionString.replace('host.docker.internal', '127.0.0.1');
     
     if (type === 'POSTGRES') {
         const client = new Client({ connectionString: localConn });
         await client.connect();
         const result = await client.query(`SELECT * FROM "${tableName}" LIMIT 50`);
         await client.end();
         res.json({ columns: result.fields.map(f => f.name), rows: result.rows });
     } else if (type === 'MONGO') {
         console.log('Connecting to MONGO with localConn:', localConn);
         const client = new MongoClient(localConn, { serverSelectionTimeoutMS: 3000 });
         await client.connect();
         console.log('Connected to MONGO successfully!');
         const db = client.db();
         const collection = db.collection(tableName);
         console.log(`Fetching from collection: ${tableName}`);
         const docs = await collection.find({}).limit(50).toArray();
         console.log(`Docs fetched: ${docs.length}`);
         await client.close();
         
         if (docs.length === 0) { res.json({ columns: [], rows: [] }); return; }
         const columns = Object.keys(docs[0]);
         res.json({ columns, rows: docs });
     } else {
         res.status(400).json({ message: 'Unknown DB type' });
     }
     
   } catch (error: any) {
     res.status(500).json({ message: 'DB Connection Error', error: error.message });
   }
};
