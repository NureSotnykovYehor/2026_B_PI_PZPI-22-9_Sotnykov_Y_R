import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import Room from '../models/Room';
import User from '../models/User';
import Evaluation from '../models/Evaluation';
import { AuthRequest } from '../middleware/auth';

export const createRoom = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const employerId = req.user?.id;
    const { taskId, duration, allowedLanguages, candidates } = req.body;

    // Fetch employer to check subscription limits
    const employer = await User.findById(employerId);
    if (!employer || employer.role !== 'EMPLOYER') {
       res.status(403).json({ message: 'Only employers can create rooms.' });
       return;
    }

    let maxCandidates = 1; // Fallback
    if (employer.subscription === 'STANDARD') maxCandidates = 10;
    else if (employer.subscription === 'PREMIUM') maxCandidates = 1000;
    
    // Explicit Invites Logic:
    let finalMaxCandidates = candidates?.length > 0 ? candidates.length : maxCandidates;
    let allowedCandidateIds: string[] = [];

    if (candidates && candidates.length > 0) {
        if (candidates.length > maxCandidates) {
            res.status(400).json({ message: `Your subscription only allows up to ${maxCandidates} candidates.` });
            return;
        }

        console.log(`\n========= DISPATCHING EXAM INVITES =========`);
        for (const candidateData of candidates) {
            let u = await User.findOne({ email: candidateData.email });
            if (!u) {
                 const salt = await bcrypt.genSalt(10);
                 const hashed = await bcrypt.hash(candidateData.password, salt);
                 u = await User.create({
                     name: candidateData.name,
                     email: candidateData.email,
                     passwordHash: hashed,
                     role: 'CANDIDATE'
                 });
                 console.log(`[MOCK EMAIL SENT] To: ${u.email} | Subject: Technical Exam Invitation | Details: Name: ${u.name}, Password: ${candidateData.password}`);
            } else {
                 console.log(`[MOCK EMAIL] Candidate ${u.email} already exists. Sending room link reminder...`);
            }
            allowedCandidateIds.push(u._id as string);
        }
        console.log(`============================================\n`);
    }

    const newRoom = new Room({
      employerId,
      taskId,
      maxCandidates: finalMaxCandidates,
      settings: {
        duration: duration || 60,
        allowedLanguages: allowedLanguages || []
      },
      allowedCandidates: allowedCandidateIds
    });

    await newRoom.save();
    res.status(201).json(newRoom);
  } catch (error: any) {
    res.status(500).json({ message: 'Error creating room', error: error.message });
  }
};

export const getEmployerRooms = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const employerId = req.user?.id;
    const rooms = await Room.find({ employerId }).populate('taskId', 'title');
    res.json(rooms);
  } catch (error: any) {
    res.status(500).json({ message: 'Error fetching rooms', error: error.message });
  }
};

export const getRoomAnalytics = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id: roomId } = req.params;
    const employerId = req.user?.id;

    // Verify room belongs to employer
    const room = await Room.findOne({ _id: roomId, employerId })
        .populate('taskId')
        .populate('allowedCandidates', 'name email');
    if (!room) {
      res.status(404).json({ message: 'Room not found or unauthorized' });
      return;
    }

    // Get evaluations for this room showing individual candidate performances
    const evaluations = await Evaluation.find({ roomId }).populate('candidateId', 'name email');
    res.json({
        room,
        analytics: evaluations
    });
  } catch (error: any) {
    res.status(500).json({ message: 'Error fetching analytics', error: error.message });
  }
};

export const getGlobalAnalytics = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const employerId = req.user?.id;
    // Find all rooms for this employer
    const rooms = await Room.find({ employerId });
    const roomIds = rooms.map(r => r._id);
    
    // Fetch all evaluations linking back to these rooms
    const evaluations = await Evaluation.find({ roomId: { $in: roomIds } })
                                        .populate('candidateId', 'name email')
                                        .populate({ path: 'roomId', populate: { path: 'taskId', select: 'title' }})
                                        .sort({ createdAt: -1 });
    res.json(evaluations);
  } catch (error: any) {
    res.status(500).json({ message: 'Error fetching global analytics', error: error.message });
  }
};

export const deleteRoom = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id: roomId } = req.params;
    const employerId = req.user?.id;

    const room = await Room.findOneAndDelete({ _id: roomId, employerId });
    if (!room) {
      res.status(404).json({ message: 'Room not found or unauthorized' });
      return;
    }
    
    // Optionally delete cascading associated data (Evaluations, Submissions)
    await Evaluation.deleteMany({ roomId });
    
    res.json({ message: 'Room deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ message: 'Error deleting room', error: error.message });
  }
};
