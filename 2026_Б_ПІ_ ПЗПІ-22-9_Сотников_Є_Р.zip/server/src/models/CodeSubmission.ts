import mongoose, { Schema, Document } from 'mongoose';

export interface ICodeSubmission extends Document {
  roomId: mongoose.Types.ObjectId;
  candidateId: mongoose.Types.ObjectId;
  code: string;
  language: string;
  status: 'SUCCESS' | 'FAILED' | 'RUNTIME_ERROR' | 'TIME_LIMIT_EXCEEDED';
  logs: string;
  timestamp: Date;
}

const CodeSubmissionSchema: Schema = new Schema({
  roomId: { type: Schema.Types.ObjectId, ref: 'Room', required: true },
  candidateId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  code: { type: String, required: true },
  language: { type: String, required: true },
  status: { type: String, enum: ['SUCCESS', 'FAILED', 'RUNTIME_ERROR', 'TIME_LIMIT_EXCEEDED'], required: true },
  logs: { type: String, default: '' },
  timestamp: { type: Date, default: Date.now }
});

export default mongoose.model<ICodeSubmission>('CodeSubmission', CodeSubmissionSchema);
