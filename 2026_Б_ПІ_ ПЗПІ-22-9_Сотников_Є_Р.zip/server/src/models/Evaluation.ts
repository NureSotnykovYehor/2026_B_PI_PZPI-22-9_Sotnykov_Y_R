import mongoose, { Schema, Document } from 'mongoose';

export interface IEvaluation extends Document {
  roomId: mongoose.Types.ObjectId;
  candidateId: mongoose.Types.ObjectId;
  candidateMetrics: {
    totalRuns: number;
    copyPasteCount: number;
    timeSpent: number; // in seconds
  };
  aiEvaluation: {
    score: number;
    summary: string;
    originalityAnalysis: string;
    bugsAnalysis: string;
    finalCode?: string;
    customAiAnomalyScore?: number;
  };
}

const EvaluationSchema: Schema = new Schema({
  roomId: { type: Schema.Types.ObjectId, ref: 'Room', required: true },
  candidateId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  candidateMetrics: {
    totalRuns: { type: Number, default: 0 },
    copyPasteCount: { type: Number, default: 0 },
    timeSpent: { type: Number, default: 0 }
  },
  aiEvaluation: {
    score: { type: Number },
    summary: { type: String },
    originalityAnalysis: { type: String },
    bugsAnalysis: { type: String },
    finalCode: { type: String },
    customAiAnomalyScore: { type: Number }
  }
}, { timestamps: true });

export default mongoose.model<IEvaluation>('Evaluation', EvaluationSchema);
