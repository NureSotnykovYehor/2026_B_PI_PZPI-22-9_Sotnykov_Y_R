import mongoose, { Schema, Document } from 'mongoose';

export interface IRoom extends Document {
  employerId: mongoose.Types.ObjectId;
  taskId: mongoose.Types.ObjectId;
  maxCandidates: number;
  status: 'OPEN' | 'CLOSED';
  settings: {
    duration: number; // in minutes
    allowedLanguages: string[];
  };
  allowedCandidates: mongoose.Types.ObjectId[];
}

const RoomSchema: Schema = new Schema({
  employerId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  taskId: { type: Schema.Types.ObjectId, ref: 'Task', required: true },
  maxCandidates: { type: Number, required: true, default: 1 },
  status: { type: String, enum: ['OPEN', 'CLOSED'], default: 'OPEN' },
  settings: {
    duration: { type: Number, default: 60 },
    allowedLanguages: [{ type: String }]
  },
  allowedCandidates: [{ type: Schema.Types.ObjectId, ref: 'User' }]
}, { timestamps: true });

export default mongoose.model<IRoom>('Room', RoomSchema);
