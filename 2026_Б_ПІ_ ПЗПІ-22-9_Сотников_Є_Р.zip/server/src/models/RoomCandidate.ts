import mongoose, { Schema, Document } from 'mongoose';

export interface IRoomCandidate extends Document {
  roomId: mongoose.Types.ObjectId;
  candidateId: mongoose.Types.ObjectId;
  status: 'INVITED' | 'IN_PROGRESS' | 'FINISHED';
  startedAt?: Date;
  endedAt?: Date;
}

const RoomCandidateSchema: Schema = new Schema({
  roomId: { type: Schema.Types.ObjectId, ref: 'Room', required: true },
  candidateId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  status: { type: String, enum: ['INVITED', 'IN_PROGRESS', 'FINISHED'], default: 'INVITED' },
  startedAt: { type: Date },
  endedAt: { type: Date }
}, { timestamps: true });

export default mongoose.model<IRoomCandidate>('RoomCandidate', RoomCandidateSchema);
