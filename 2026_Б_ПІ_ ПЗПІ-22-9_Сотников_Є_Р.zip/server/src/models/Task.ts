import mongoose, { Schema, Document } from 'mongoose';

export interface ITask extends Document {
  title: string;
  description: string;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
  starterCode: Map<string, string>; // Language -> Code
  testCases: Array<{
    input: string;
    expectedOutput: string;
    isHidden: boolean;
  }>;
  timeLimit: number; // in ms
  memoryLimit: number; // in MB
  dbIntegration?: {
    type: 'NONE' | 'POSTGRES' | 'MONGO';
    connectionString: string;
    tableName: string;
  };
}

const TaskSchema: Schema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  difficulty: { type: String, required: true, enum: ['EASY', 'MEDIUM', 'HARD'] },
  starterCode: { type: Map, of: String, default: {} },
  testCases: [{
    input: { type: String, required: true },
    expectedOutput: { type: String, required: true },
    isHidden: { type: Boolean, default: false }
  }],
  timeLimit: { type: Number, default: 5000 },
  memoryLimit: { type: Number, default: 256 },
  dbIntegration: {
    type: { type: String, enum: ['NONE', 'POSTGRES', 'MONGO'], default: 'NONE' },
    connectionString: { type: String, default: '' },
    tableName: { type: String, default: '' }
  }
}, { timestamps: true });

export default mongoose.model<ITask>('Task', TaskSchema);
