import mongoose, { Schema, Document } from 'mongoose';

export type TypingEventType = 'copy' | 'paste' | 'type' | 'delete' | 'tab_switch';

export interface ITypingEvent {
  type: TypingEventType;
  timestamp: Date;
  details?: string; // E.g., the pasted text, or switch reason
}

export interface ITypingMetrics extends Document {
  roomId: mongoose.Types.ObjectId;
  candidateId: mongoose.Types.ObjectId;
  events: ITypingEvent[];
  tabSwitchesCount: number;
}

const TypingEventSchema = new Schema<ITypingEvent>({
  type: { type: String, enum: ['copy', 'paste', 'type', 'delete', 'tab_switch'], required: true },
  timestamp: { type: Date, required: true },
  details: { type: String }
}, { _id: false });

const TypingMetricsSchema: Schema = new Schema({
  roomId: { type: Schema.Types.ObjectId, ref: 'Room', required: true },
  candidateId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  events: { type: [TypingEventSchema], default: [] },
  tabSwitchesCount: { type: Number, default: 0 }
}, { timestamps: true });

export default mongoose.model<ITypingMetrics>('TypingMetrics', TypingMetricsSchema);
