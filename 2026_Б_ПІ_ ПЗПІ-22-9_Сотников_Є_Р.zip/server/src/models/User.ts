import mongoose, { Schema, Document } from 'mongoose';

export enum SubscriptionTier {
  STANDARD = 'STANDARD',
  PREMIUM = 'PREMIUM',
}

export interface IUser extends Document {
  email: string;
  passwordHash?: string;
  name: string;
  role: 'EMPLOYER' | 'CANDIDATE' | 'ADMIN';
  subscription?: SubscriptionTier;
  companyId?: string;
  googleId?: string;
  companyName?: string;
  jobTitle?: string;
  avatarUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema: Schema = new Schema({
  email: { type: String, required: true, unique: true },
  passwordHash: { type: String, required: false }, // Optional for Google OAuth users
  name: { type: String, required: true },
  role: { type: String, required: true, enum: ['EMPLOYER', 'CANDIDATE', 'ADMIN'], default: 'CANDIDATE' },
  subscription: { type: String, enum: Object.values(SubscriptionTier), default: 'STANDARD' },
  companyId: { type: String },
  googleId: { type: String, unique: true, sparse: true },
  companyName: { type: String },
  jobTitle: { type: String },
  avatarUrl: { type: String },
}, { timestamps: true });

export default mongoose.model<IUser>('User', UserSchema);
