import { Router } from 'express';
import { register, login, googleLogin } from '../controllers/authController';
import { authenticate } from '../middleware/auth';
import { AuthRequest } from '../middleware/auth';
import User from '../models/User';

const router = Router();

router.post('/register', register);
router.post('/login', login);
router.post('/google', googleLogin);

router.get('/me', authenticate, async (req: AuthRequest, res) => {
  try {
    const user = await User.findById(req.user?.id).select('-passwordHash');
    if (!user) {
      res.status(404).json({ message: 'User not found' });
      return;
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
