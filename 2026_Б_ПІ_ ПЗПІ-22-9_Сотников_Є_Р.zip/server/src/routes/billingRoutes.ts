import { Router } from 'express';
import { generatePaymentParams, liqpayCallback, mockPaymentSuccess } from '../controllers/billingController';
import { authenticate } from '../middleware/auth';

const router = Router();

// Endpoint for the frontend to request payment signature
router.get('/liqpay-params', authenticate, generatePaymentParams);

// Webhook endpoint for LiqPay Server-to-Server callback
// Note: no authMiddleware here because it's called by LiqPay
router.post('/liqpay-callback', liqpayCallback);
// Mock endpoint for local testing
router.post('/mock-success', authenticate, mockPaymentSuccess);

export default router;
