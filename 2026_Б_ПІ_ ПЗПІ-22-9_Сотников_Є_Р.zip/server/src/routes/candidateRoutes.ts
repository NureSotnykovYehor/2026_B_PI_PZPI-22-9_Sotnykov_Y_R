import { Router } from 'express';
import { joinRoom, submitMetrics, runCode, finishSession, getDbPreview } from '../controllers/candidateController';
import { authenticate } from '../middleware/auth';

const router = Router();

// Secure candidate operations
router.use(authenticate);

// Candidate exam routes
// /api/candidate/rooms/:id/join
router.post('/rooms/:id/join', joinRoom);
router.post('/rooms/:id/metrics', submitMetrics);
router.post('/rooms/:id/run', runCode);
router.post('/rooms/:id/finish', finishSession);
router.get('/rooms/:id/db-preview', getDbPreview);

export default router;
