import { Router } from 'express';
import { createRoom, getEmployerRooms, getRoomAnalytics, getGlobalAnalytics, deleteRoom } from '../controllers/roomController';
import { authenticate, authorizeRoles } from '../middleware/auth';

const router = Router();

// Protect all routes with JWT auth
router.use(authenticate);

// Employer endpoints
router.post('/', authorizeRoles('EMPLOYER', 'ADMIN'), createRoom);
router.get('/', authorizeRoles('EMPLOYER', 'ADMIN'), getEmployerRooms);
router.get('/analytics/global', authorizeRoles('EMPLOYER', 'ADMIN'), getGlobalAnalytics);
router.get('/:id/analytics', authorizeRoles('EMPLOYER', 'ADMIN'), getRoomAnalytics);
router.delete('/:id', authorizeRoles('EMPLOYER', 'ADMIN'), deleteRoom);

export default router;
