import { Router } from 'express';
import { createTask, getTasks, getTaskById, updateTask, deleteTask } from '../controllers/taskController';
import { authenticate, authorizeRoles } from '../middleware/auth';

const router = Router();

// Setup standard CRUD routes for tasks
// Only EMPLOYER and ADMIN can manage tasks. If CANDIDATE needs to read a task, they might do it through a Room endpoint, or we can allow GET for them.
// Let's allow GET for all authenticated users, but POST, PUT, DELETE for employers.
router.get('/', authenticate, getTasks);
router.get('/:id', authenticate, getTaskById);

router.post('/', authenticate, authorizeRoles('EMPLOYER', 'ADMIN'), createTask);
router.put('/:id', authenticate, authorizeRoles('EMPLOYER', 'ADMIN'), updateTask);
router.delete('/:id', authenticate, authorizeRoles('EMPLOYER', 'ADMIN'), deleteTask);

export default router;
