import mongoose from 'mongoose';
import dotenv from 'dotenv';
import bcrypt from 'bcrypt';
import User from './models/User';
import Task from './models/Task';
import Room from './models/Room';
import RoomCandidate from './models/RoomCandidate';
import CodeSubmission from './models/CodeSubmission';
import Evaluation from './models/Evaluation';
import TypingMetrics from './models/TypingMetrics';

dotenv.config();

const seedDB = async () => {
    try {
        const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/techscreen';
        await mongoose.connect(mongoUri);
        console.log('Connected to DB. Commencing FULL SYSTEM WIPE...');

        // Clear ALL existing docs
        await User.deleteMany({});
        await Task.deleteMany({});
        await Room.deleteMany({});
        await RoomCandidate.deleteMany({});
        await CodeSubmission.deleteMany({});
        await Evaluation.deleteMany({});
        await TypingMetrics.deleteMany({});

        // CREATE DUMMY MONGO DATA FOR EXAM
        const db = mongoose.connection.db;
        if (db) {
           const collection = db.collection('interview_users');
           await collection.deleteMany({});
           await collection.insertMany([
              { username: "john_doe", role: "admin", active: true },
              { username: "jane_smith", role: "user", active: false },
              { username: "bob_builder", role: "user", active: true }
           ]);
           console.log('✅ Dummy Database "interview_users" populated for candidates.');
        }

        console.log('✅ Base models completely wiped.');

        // Add Mock Users
        const salt = await bcrypt.genSalt(10);
        const passwordHash = await bcrypt.hash('password123', salt);
        const candPasswordHash = await bcrypt.hash('12345', salt);

        const employer = await User.create({
            name: 'John Employer',
            email: 'employer@test.com',
            passwordHash: passwordHash,
            role: 'EMPLOYER',
            subscription: 'PRO'
        });

        const candidate1 = await User.create({
            name: 'Ivan Ivanov',
            email: 'ivan@test.com',
            passwordHash: candPasswordHash,
            role: 'CANDIDATE'
        });

        const candidate2 = await User.create({
            name: 'Jane Doe',
            email: 'jane@test.com',
            passwordHash: candPasswordHash,
            role: 'CANDIDATE'
        });

        console.log('✅ Users created: employer@test.com and candidate@test.com');

        // Add Room 1: Algorithm
        const task1 = await Task.create({
            title: 'Algorithm: Invert Binary Tree',
            description: 'Write a JavaScript function that inverts a binary tree.',
            difficulty: 'MEDIUM',
            starterCode: { 'javascript': 'function invertTree(root) {\n  // Your logic here\n}' },
            testCases: [
                { 
                    input: 'invertTree({val: 2, left: {val: 1}, right: {val: 3}})', 
                    expectedOutput: '{"val":2,"left":{"val":3},"right":{"val":1}}', 
                    isHidden: false 
                }
            ],
            dbIntegration: { type: 'NONE', connectionString: '', tableName: '' }
        });

        const room1 = await Room.create({
            employerId: employer._id,
            taskId: task1._id,
            status: 'OPEN',
            maxCandidates: 1, // Only 1 person config
            settings: { duration: 30, allowedLanguages: ['javascript'] }
        });

        // Add Room 2: Database Task
        const task2 = await Task.create({
            title: 'Database: Fetch Active Users',
            description: 'Connect to Mongo using process.env.DB_CONNECTION_STRING. Fetch only active users from the "interview_users" collection.',
            difficulty: 'HARD',
            starterCode: { 'javascript': 'const { MongoClient } = require("mongodb");\n\nasync function main() {\n  const uri = process.env.DB_CONNECTION_STRING;\n  const client = new MongoClient(uri);\n  await client.connect();\n  \n  const db = client.db();\n  const collection = db.collection("interview_users");\n  // Write logic to find active users\n\n  await client.close();\n}\nmain();' },
            testCases: [],
            dbIntegration: { 
               type: 'MONGO', 
               connectionString: mongoUri, 
               tableName: 'interview_users' 
            }
        });

        const room2 = await Room.create({
            employerId: employer._id,
            taskId: task2._id,
            status: 'OPEN',
            maxCandidates: 10,
            settings: { duration: 60, allowedLanguages: ['javascript'] }
        });

        // Add Room 3: DB Task with asynchronous tests
        const task3 = await Task.create({
            title: 'Database: Count Active Users with Tests',
            description: 'Write an asynchronous function `countActiveUsers()` that uses `process.env.DB_CONNECTION_STRING` to connect to Mongo, queries the `interview_users` collection for users with `status: "active"`, and returns the integer count of such users.',
            difficulty: 'HARD',
            starterCode: { 'javascript': 'const { MongoClient } = require("mongodb");\n\n// 1. Create an async function called countActiveUsers\n// 2. Connect to Mongo using process.env.DB_CONNECTION_STRING\n// 3. Query the collection interview_users for active users\n// 4. Return the integer count of how many active users there are.\nasync function countActiveUsers() {\n  const uri = process.env.DB_CONNECTION_STRING;\n  const client = new MongoClient(uri);\n  await client.connect();\n  const db = client.db();\n  // Your logic here\n}' },
            testCases: [
                {
                    input: 'countActiveUsers()',
                    expectedOutput: 2,
                    isHidden: false
                }
            ],
            dbIntegration: { 
               type: 'MONGO', 
               connectionString: mongoUri, 
               tableName: 'interview_users' 
            }
        });

        const room3 = await Room.create({
            employerId: employer._id,
            taskId: task3._id,
            status: 'OPEN',
            maxCandidates: 10,
            settings: { duration: 45, allowedLanguages: ['javascript'] }
        });

        console.log(`✅ Room 1 (Algorithm) created: ${room1._id}`);
        console.log(`✅ Room 2 (Database Mongo) created: ${room2._id}`);
        console.log(`✅ Room 3 (DB with async tests) created: ${room3._id}`);
        console.log('🚀 Seeding completed successfully!');
        console.log('\n=============================================');
        console.log('         MOCK EXAM ACCOUNTS GENERATED          ');
        console.log('=============================================');
        console.log('EMPLOYER : employer@test.com / password123');
        console.log('CANDIDATE 1 : ivan@test.com / 12345');
        console.log('CANDIDATE 2 : jane@test.com / 12345');
        console.log('=============================================\n');
        process.exit();
    } catch (err) {
        console.error('Seeding error:', err);
        process.exit(1);
    }
};

seedDB();
