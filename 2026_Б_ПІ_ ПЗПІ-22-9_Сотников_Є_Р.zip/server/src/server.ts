import express from 'express';
import http from 'http';
import { Server, Socket } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import connectDB from './config/db';

import authRoutes from './routes/authRoutes';
import taskRoutes from './routes/taskRoutes';
import roomRoutes from './routes/roomRoutes';
import candidateRoutes from './routes/candidateRoutes';
import billingRoutes from './routes/billingRoutes';
import profileRoutes from './routes/profileRoutes';
import { setupSockets } from './sockets/socketHandler';

dotenv.config();

export const app = express();
const server = http.createServer(app);

// Keep options simple for initial setup
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

setupSockets(io);

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/candidate', candidateRoutes);
app.use('/api/billing', billingRoutes);
app.use('/api/profile', profileRoutes);

// Basic Route
app.get('/api/health', (req, res) => {
  res.json({ status: 'Platform is running...' });
});


const PORT = process.env.PORT || 4000;

export const startServer = async () => {
  await connectDB();
  server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
};

if (process.env.NODE_ENV !== 'test') {
    startServer();
}
