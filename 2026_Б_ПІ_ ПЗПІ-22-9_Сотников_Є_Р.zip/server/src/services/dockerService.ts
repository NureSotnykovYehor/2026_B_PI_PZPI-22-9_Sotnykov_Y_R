import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';

const execPromise = promisify(exec);

export const executeCodeInDocker = async (code: string, language: string, dbConnectionString: string = ""): Promise<{ status: 'SUCCESS' | 'FAILED' | 'RUNTIME_ERROR' | 'TIME_LIMIT_EXCEEDED', logs: string }> => {
   const tempId = Date.now().toString();
   const tempDir = path.resolve(__dirname, '../../temp', tempId);
   
   if (!fs.existsSync(tempDir)) {
     fs.mkdirSync(tempDir, { recursive: true });
   }

   let fileName = 'main.txt';
   let dockerImage = '';
   let runCommand = '';

   if (language.toLowerCase() === 'javascript') {
     fileName = 'main.js';
     dockerImage = 'node:18-alpine';
     runCommand = `node ${fileName}`;
   } else if (language.toLowerCase() === 'python') {
     fileName = 'main.py';
     dockerImage = 'python:3.9-slim';
     runCommand = `python ${fileName}`;
   } else {
     return { status: 'FAILED', logs: 'Language not supported for execution.' };
   }

   const filePath = path.join(tempDir, fileName);
   fs.writeFileSync(filePath, code);

   try {
     // Run container with both tempDir (for code) and server's node_modules properly injected.
     // Also inject the connection string for candidate logic usage inside Docker
     const serverPath = path.resolve(__dirname, '../../');
     const envFlags = dbConnectionString ? `-e DB_CONNECTION_STRING="${dbConnectionString}"` : '';
     
     const { stdout, stderr } = await execPromise(
       `docker run --rm --net host --memory 256m ${envFlags} -v "${tempDir}":/app -v "${serverPath}/node_modules":/app/node_modules -w /app ${dockerImage} ${runCommand}`,
       { timeout: 5000 } // 5 seconds constraint
     );

     return {
       status: 'SUCCESS',
       logs: stdout || stderr || 'Executed successfully with no console output.'
     };

   } catch (error: any) {
     if (error.killed) {
       return { status: 'TIME_LIMIT_EXCEEDED', logs: 'Execution timed out (exceeded 5 seconds).' };
     }

     // Local fallback if Docker is not running (Development only)
     if (error.message && error.message.includes('error during connect')) {
       console.warn("Docker not running! Falling back to local execution.");
       try {
         const { stdout, stderr } = await execPromise(`${runCommand}`, { cwd: tempDir, timeout: 5000 });
         return {
           status: 'SUCCESS',
           logs: stdout || stderr || 'Executed successfully with no console output (Local Fallback).'
         };
       } catch (localErr: any) {
         return {
           status: 'RUNTIME_ERROR',
           logs: localErr.stderr || localErr.stdout || localErr.message
         };
       }
     }
     
     return { 
       status: 'RUNTIME_ERROR', 
       logs: error.stderr || error.message || 'Unknown runtime error'
     };
   } finally {
     if (fs.existsSync(tempDir)) {
       fs.rmSync(tempDir, { recursive: true, force: true });
     }
   }
};
