import * as brain from 'brain.js';
import fs from 'fs';
import path from 'path';

// Path for the trained model
const MODEL_PATH = path.join(__dirname, 'trained-model.json');

// Initialize a FeedForward Neural Network
const anomalyNet = new brain.NeuralNetwork({
  hiddenLayers: [5, 5]
});

// Train the network with expanded behavior patterns
// Input structure: [timeSpentNorm, totalRunsNorm, pasteCountNorm, tabSwitchCountNorm, errorRateNorm]
// timeSpentNorm: 1.0 = normal (e.g. >15 mins), 0.0 = too fast (0 mins)
// totalRunsNorm: 1.0 = multiple runs, 0.0 = zero runs before submit
// pasteCountNorm: 1.0 = 0 pastes, 0.0 = many pastes (>5)
// tabSwitchCountNorm: 1.0 = 0 tab switches, 0.0 = many tab switches (>5)
// errorRateNorm: 1.0 = normal (made some errors, e.g. >20% failure rate), 0.0 = suspicious (perfect code on first try)

// Output: { cheatProbability: percentage }
const trainingData = [
  // Perfect honest student (took time, ran code, no pastes, made some errors before succeeding)
  { input: [1.0, 1.0, 1.0, 1.0, 1.0], output: { cheatProbability: 0.01 } },
  // Normal honest student (maybe pasted a small snippet once, had some errors)
  { input: [0.8, 0.8, 0.8, 1.0, 0.9], output: { cheatProbability: 0.05 } },
  // Struggles but honest (lots of errors, lots of time)
  { input: [1.0, 1.0, 1.0, 0.8, 1.0], output: { cheatProbability: 0.02 } },

  // Suspicious: fast time, zero runs, 1 massive paste, zero errors (because no runs)
  { input: [0.1, 0.0, 0.1, 1.0, 0.0], output: { cheatProbability: 0.95 } },
  
  // Tab switcher and paster (Googling a lot)
  { input: [0.5, 0.2, 0.0, 0.0, 0.5], output: { cheatProbability: 0.88 } },
  
  // Instant submission, no runs, no pastes (pure typing bot or bypass)
  { input: [0.0, 0.0, 1.0, 1.0, 0.0], output: { cheatProbability: 0.99 } },

  // "Genius" bypass: Fast time, 1 perfect run (0 errors), no pastes, no tab switches
  // Highly likely they wrote it on another screen and typed it in, or used an extension
  { input: [0.2, 0.3, 1.0, 1.0, 0.0], output: { cheatProbability: 0.80 } },

  // Heavy struggling: Max time, max runs, max errors, 0 pastes
  { input: [1.0, 1.0, 1.0, 1.0, 1.0], output: { cheatProbability: 0.01 } },

  // Suspicious: Lots of time, but 0 runs, 0 errors, 1 big paste at the end
  { input: [1.0, 0.0, 0.0, 1.0, 0.0], output: { cheatProbability: 0.90 } },

  // Tab switcher, but normal runs and errors (maybe researching syntax, but coding honestly)
  { input: [0.8, 0.8, 1.0, 0.0, 0.8], output: { cheatProbability: 0.20 } }
];

// Try to load existing model, otherwise train and save
if (fs.existsSync(MODEL_PATH)) {
  try {
    const rawData = fs.readFileSync(MODEL_PATH, 'utf-8');
    anomalyNet.fromJSON(JSON.parse(rawData));
    console.log('[Local AI] Successfully loaded trained ML model from disk.');
  } catch (err) {
    console.error('[Local AI] Failed to load model, retraining...', err);
    trainAndSaveModel();
  }
} else {
  console.log('[Local AI] No trained model found. Training new network...');
  trainAndSaveModel();
}

function trainAndSaveModel() {
  anomalyNet.train(trainingData, {
    iterations: 3000,
    errorThresh: 0.004,
    log: true,
    logPeriod: 500
  });

  try {
    fs.writeFileSync(MODEL_PATH, JSON.stringify(anomalyNet.toJSON()), 'utf-8');
    console.log('[Local AI] Successfully trained and saved ML model to disk.');
  } catch (err) {
    console.error('[Local AI] Failed to save trained model:', err);
  }
}

/**
 * Predicts cheating probability using the Local ML model based on metrics.
 */
export const predictCheatProbability = (
  timeSpentSeconds: number, 
  totalRuns: number, 
  pasteCount: number, 
  tabSwitchCount: number,
  errorRate: number // 0.0 to 1.0
): number => {
  // Normalize inputs (heuristic bounds)
  // Max expected time = 1800s (30m). Closer to 0 = worse (0.0). Closer to 1800 = good (1.0).
  const timeSpentNorm = Math.min(timeSpentSeconds / 900, 1.0); 
  
  // Runs: 0 = bad (0.0), 3+ = good (1.0)
  const totalRunsNorm = Math.min(totalRuns / 3, 1.0);
  
  // Pastes: 0 = good (1.0), 5+ = bad (0.0)
  const pasteCountNorm = Math.max(0, 1.0 - (pasteCount / 5));
  
  // Tabs: 0 = good (1.0), 5+ = bad (0.0)
  const tabSwitchCountNorm = Math.max(0, 1.0 - (tabSwitchCount / 5));

  // Error Rate: 0 errors is highly suspicious in algorithmic tasks (0.0). Making errors is normal (1.0)
  // Assuming a normal error rate is around 30%+ of submissions failing at first
  const errorRateNorm = Math.min(errorRate * 3, 1.0);

  const result = anomalyNet.run([
    timeSpentNorm,
    totalRunsNorm,
    pasteCountNorm,
    tabSwitchCountNorm,
    errorRateNorm
  ]) as { cheatProbability: number };

  // Return as percentage 0-100
  return Math.round(result.cheatProbability * 100);
};
