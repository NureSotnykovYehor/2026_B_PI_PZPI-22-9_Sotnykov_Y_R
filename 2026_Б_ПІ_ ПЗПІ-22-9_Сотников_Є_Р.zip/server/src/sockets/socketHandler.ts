import { Server, Socket } from 'socket.io';

// Extending Socket interface to hold custom data temporarily during the connection
interface InterviewSocket extends Socket {
  roomId?: string;
  userId?: string;
  role?: string;
}

export const setupSockets = (io: Server) => {
  io.on('connection', (socket: InterviewSocket) => {
    console.log(`User connected via WS: ${socket.id}`);

    // Candidate or Employer joins the room
    socket.on('joinRoom', ({ roomId, userId, role }) => {
      socket.join(roomId);
      socket.roomId = roomId;
      socket.userId = userId;
      socket.role = role;

      console.log(`User ${userId} (${role}) joined Room: ${roomId}`);

      // If a candidate joins, tell the room (Employer) they are ONLINE
      if (role === 'CANDIDATE') {
        socket.to(roomId).emit('candidateStatus', { 
            userId, 
            status: 'ONLINE' 
        });
      }
    });

    // Real-time Anti-Cheat or Live Activity Indicator
    socket.on('candidateActivity', ({ status }) => {
      // status can be 'TYPING', 'IDLE', 'TAB_SWITCHED'
      if (socket.roomId && socket.role === 'CANDIDATE') {
        socket.to(socket.roomId).emit('candidateActivityUpdate', {
          userId: socket.userId,
          status
        });
      }
    });

    // Handling sudden disconnections 
    socket.on('disconnect', () => {
      console.log(`User disconnected: ${socket.id} (${socket.userId})`);
      
      if (socket.roomId && socket.role === 'CANDIDATE') {
         socket.to(socket.roomId).emit('candidateStatus', { 
             userId: socket.userId, 
             status: 'OFFLINE' 
         });
      }
    });
  });
};
