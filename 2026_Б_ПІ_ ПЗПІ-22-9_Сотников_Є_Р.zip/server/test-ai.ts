import { predictCheatProbability } from './src/services/localAi';
import fs from 'fs';

console.log('--- Testing Local AI ---');

const checkModelCreated = fs.existsSync('./src/services/trained-model.json');
console.log('Model file exists:', checkModelCreated);

// 1. "Genius Bypass": 10 seconds, 1 run, 0 pastes, 0 tabs, 0 errors
const p1 = predictCheatProbability(10, 1, 0, 0, 0);
console.log(`Genius Bypass Probability: ${p1}%`);

// 2. "Honest Developer": 25 minutes, 8 runs, 0 pastes, 2 tabs, 3 errors (error rate = 3/8 = 0.375)
const p2 = predictCheatProbability(1500, 8, 0, 2, 0.375);
console.log(`Honest Dev Probability: ${p2}%`);

// 3. "Heavy Paster": 5 minutes, 2 runs, 6 pastes, 4 tabs, 1 error (error rate = 0.5)
const p3 = predictCheatProbability(300, 2, 6, 4, 0.5);
console.log(`Heavy Paster Probability: ${p3}%`);
