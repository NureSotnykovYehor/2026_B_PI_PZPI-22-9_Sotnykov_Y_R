const dns = require('dns');
dns.lookup('localhost', (err, address, family) => {
    console.log('localhost address: %j family: IPv%s', address, family);
});
