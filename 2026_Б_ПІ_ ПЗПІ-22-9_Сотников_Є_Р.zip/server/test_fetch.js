const jwt = require('jsonwebtoken');
const token = jwt.sign({ id: '69e2b6b01ea6c980bb2b7b63', role: 'CANDIDATE' }, process.env.JWT_SECRET || 'supersecret_jwt_key', { expiresIn: '1d' });
fetch("http://localhost:4000/api/candidate/rooms/69e2b6b01ea6c980bb2b7b67/db-preview", {
   headers: { "Authorization": "Bearer " + token }
}).then(r=>r.text()).then(console.log).catch(console.error);
