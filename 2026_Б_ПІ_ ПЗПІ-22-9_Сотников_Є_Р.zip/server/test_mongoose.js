const mongoose = require('mongoose');

async function test() {
   try {
      const conn = await mongoose.createConnection('mongodb://127.0.0.1:27017/techscreen').asPromise();
       console.log("Connected");
       const collection = conn.collection('interview_users');
       console.log("Collection got");
       const docs = await collection.find({}).limit(50).toArray();
       console.log("Docs:", docs);
       await conn.close();
   } catch(e) {
       console.error(e);
   }
}

test();
