const mongoose = require('mongoose');

async function test() {
   try {
      const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/technical-interview-platform';
      await mongoose.connect(uri);
      
      const Task = mongoose.connection.collection('tasks');
      const docs = await Task.find({}).toArray();
      console.log('Tasks in DB:');
      docs.forEach(d => {
         if (d.dbIntegration && d.dbIntegration.type !== 'NONE') {
             console.log(d.title, d.dbIntegration);
         }
      });
      await mongoose.disconnect();
   } catch(e) {
       console.error(e);
   }
}

test();
