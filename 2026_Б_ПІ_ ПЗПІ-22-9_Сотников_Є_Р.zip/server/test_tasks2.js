const { MongoClient } = require('mongodb');

async function test() {
   try {
      const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/technical-interview-platform';
      const client = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
      await client.connect();
      
      const db = client.db();
      const docs = await db.collection('tasks').find({}).toArray();
      console.log('Tasks in DB:');
      docs.forEach(d => {
         if (d.dbIntegration && d.dbIntegration.type !== 'NONE') {
             console.log("Found task DB connection String:", d.dbIntegration.connectionString);
         }
      });
      await client.close();
   } catch(e) {
       console.error("Test Error:", e);
   }
}

test();
