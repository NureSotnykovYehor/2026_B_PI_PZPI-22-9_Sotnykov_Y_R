const { MongoClient } = require('mongodb');

async function test() {
   try {
      const uri = 'mongodb://localhost:27017/technical-interview-platform';
      const client = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
      await client.connect();
      console.log('Connected natively to Mongo IPv6 via localhost!');
      await client.close();
   } catch(e) {
       console.error("Test Error:", e);
   }
}

test();
