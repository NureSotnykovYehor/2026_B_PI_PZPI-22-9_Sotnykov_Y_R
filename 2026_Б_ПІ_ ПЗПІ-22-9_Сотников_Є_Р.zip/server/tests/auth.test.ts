import request from 'supertest';
import { app } from '../src/server';
import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';

let mongoServer: MongoMemoryServer;

beforeAll(async () => {
    mongoServer = await MongoMemoryServer.create();
    const uri = mongoServer.getUri();
    await mongoose.connect(uri);
});

afterAll(async () => {
    await mongoose.connection.dropDatabase();
    await mongoose.connection.close();
    await mongoServer.stop();
});

describe('Auth API Checks', () => {
    let mockUser = {
        email: 'testauth@user.com',
        password: 'password123',
        name: 'Test Auth User',
        role: 'EMPLOYER'
    };

    it('should register a new user', async () => {
        const res = await request(app)
            .post('/api/auth/register')
            .send(mockUser);
            
        expect(res.status).toBe(201);
        expect(res.body.message).toBe('User registered successfully');
    });

    it('should login previously registered user and return token', async () => {
        const res = await request(app)
            .post('/api/auth/login')
            .send({
                email: mockUser.email,
                password: mockUser.password
            });
            
        expect(res.status).toBe(200);
        expect(res.body).toHaveProperty('token');
        expect(res.body.user.role).toBe('EMPLOYER');
    });

    it('should fail login with bad password', async () => {
        const res = await request(app)
            .post('/api/auth/login')
            .send({
                email: mockUser.email,
                password: 'wrongpassword'
            });
            
        expect(res.status).toBe(400); 
    });
});
