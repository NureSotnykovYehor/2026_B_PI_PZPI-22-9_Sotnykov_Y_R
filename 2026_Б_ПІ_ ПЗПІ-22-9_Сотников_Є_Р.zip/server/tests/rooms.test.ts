import request from 'supertest';
import { app } from '../src/server';
import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';

let mongoServer: MongoMemoryServer;
let employerToken: string;
let taskId: string;

beforeAll(async () => {
    mongoServer = await MongoMemoryServer.create();
    const uri = mongoServer.getUri();
    await mongoose.connect(uri);

    // Register Free Employer
    await request(app).post('/api/auth/register').send({
        email: 'free@test.com', password: 'password123', name: 'Free Employer', role: 'EMPLOYER'
    });
    
    let res = await request(app).post('/api/auth/login').send({ email: 'free@test.com', password: 'password123' });
    employerToken = res.body.token;

    // Create a mock task to associate with room
    res = await request(app).post('/api/tasks').set('Authorization', `Bearer ${employerToken}`).send({
        title: 'Basic Task', description: 'Desc', difficulty: 'EASY'
    });
    taskId = res.body._id;
});

afterAll(async () => {
    await mongoose.connection.dropDatabase();
    await mongoose.connection.close();
    await mongoServer.stop();
});

describe('Rooms CRUD API', () => {
    let roomId: string;

    it('should create a new Room associated with Employer', async () => {
        const res = await request(app)
            .post('/api/rooms')
            .set('Authorization', `Bearer ${employerToken}`)
            .send({
                taskId: taskId,
                duration: 30,
                allowedLanguages: ['javascript']
            });

        expect(res.status).toBe(201);
        // FREE tier automatically limits maxCandidates to 1
        expect(res.body.maxCandidates).toBe(1);
        roomId = res.body._id;
    });

    it('should retrieve list of rooms for Employer', async () => {
        const res = await request(app)
            .get('/api/rooms')
            .set('Authorization', `Bearer ${employerToken}`);

        expect(res.status).toBe(200);
        expect(res.body.length).toBe(1);
        expect(res.body[0]._id).toBe(roomId);
    });
});
