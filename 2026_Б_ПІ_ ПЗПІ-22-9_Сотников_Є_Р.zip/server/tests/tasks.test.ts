import request from 'supertest';
import { app } from '../src/server';
import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';

let mongoServer: MongoMemoryServer;
let employerToken: string;
let candidateToken: string;

beforeAll(async () => {
    mongoServer = await MongoMemoryServer.create();
    const uri = mongoServer.getUri();
    await mongoose.connect(uri);

    await request(app).post('/api/auth/register').send({
        email: 'employer@test.com', password: 'password123', name: 'Task Master', role: 'EMPLOYER'
    });
    
    await request(app).post('/api/auth/register').send({
        email: 'cand@test.com', password: 'password123', name: 'Cand', role: 'CANDIDATE'
    });

    let res = await request(app).post('/api/auth/login').send({ email: 'employer@test.com', password: 'password123' });
    employerToken = res.body.token;

    res = await request(app).post('/api/auth/login').send({ email: 'cand@test.com', password: 'password123' });
    candidateToken = res.body.token;
});

afterAll(async () => {
    await mongoose.connection.dropDatabase();
    await mongoose.connection.close();
    await mongoServer.stop();
});

describe('Tasks CRUD API', () => {
    let taskId: string;

    it('should block candidate from creating tasks', async () => {
        const res = await request(app)
            .post('/api/tasks')
            .set('Authorization', `Bearer ${candidateToken}`)
            .send({ title: 'Hack', description: 'Hack', difficulty: 'HARD' });
        expect(res.status).toBe(403);
    });

    it('should create a task when logged in as employer', async () => {
        const res = await request(app)
            .post('/api/tasks')
            .set('Authorization', `Bearer ${employerToken}`)
            .send({
                title: 'Test Task',
                description: 'A mock description',
                difficulty: 'EASY'
            });

        expect(res.status).toBe(201);
        expect(res.body.title).toBe('Test Task');
        taskId = res.body._id;
    });

    it('should list employer tasks', async () => {
        const res = await request(app)
            .get('/api/tasks')
            .set('Authorization', `Bearer ${employerToken}`);

        expect(res.status).toBe(200);
        expect(res.body.length).toBe(1);
    });
});
